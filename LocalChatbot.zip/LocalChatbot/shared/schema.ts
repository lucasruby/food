import { pgTable, text, serial, integer, boolean, jsonb, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("customer"), // developer, admin, customer
  businessId: integer("business_id"),
  name: text("name"),
  email: text("email"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const businesses = pgTable("businesses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("pizzaria"),
  logo: text("logo"),
  address: text("address"),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow()
});

export const pizzas = pgTable("pizzas", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  ingredients: text("ingredients").array(),
  price: real("price").notNull(),
  size: text("size").notNull(), // Small, Medium, Large, Giant
  category: text("category").notNull(), // Traditional, Special, Sweet
  active: boolean("active").default(true)
});

export const menuItems = pgTable("menu_items", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  price: real("price").notNull(),
  category: text("category").notNull(), // Drinks, Sides, etc.
  active: boolean("active").default(true)
});

export const promotions = pgTable("promotions", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: real("price").notNull(),
  items: jsonb("items").notNull(),
  active: boolean("active").default(true)
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  customerAddress: text("customer_address"),
  items: jsonb("items").notNull(),
  total: real("total").notNull(),
  status: text("status").notNull().default("pending"), // pending, preparing, delivering, completed, cancelled
  paymentMethod: text("payment_method").notNull(),
  paymentStatus: text("payment_status").notNull().default("pending"), // pending, paid, failed
  createdAt: timestamp("created_at").defaultNow()
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  address: text("address"),
  orderCount: integer("order_count").default(0),
  createdAt: timestamp("created_at").defaultNow()
});

export const prompts = pgTable("prompts", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  name: text("name").notNull().default("default"),
  content: text("content").notNull(),
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow()
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull(),
  customerPhone: text("customer_phone").notNull(),
  messages: jsonb("messages").notNull().default([]),
  status: text("status").notNull().default("active"), // active, completed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow()
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  businessId: true,
  name: true,
  email: true,
  phone: true,
});

export const insertBusinessSchema = createInsertSchema(businesses).pick({
  name: true,
  type: true,
  logo: true,
  address: true,
  phone: true,
});

export const insertPizzaSchema = createInsertSchema(pizzas).pick({
  businessId: true,
  name: true,
  description: true,
  ingredients: true,
  price: true,
  size: true,
  category: true,
  active: true,
});

export const insertMenuItemSchema = createInsertSchema(menuItems).pick({
  businessId: true,
  name: true,
  description: true,
  price: true,
  category: true,
  active: true,
});

export const insertPromotionSchema = createInsertSchema(promotions).pick({
  businessId: true,
  name: true,
  description: true,
  price: true,
  items: true,
  active: true,
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  businessId: true,
  customerName: true,
  customerPhone: true,
  customerAddress: true,
  items: true,
  total: true,
  status: true,
  paymentMethod: true,
  paymentStatus: true,
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  businessId: true,
  name: true,
  phone: true,
  address: true,
});

export const insertPromptSchema = createInsertSchema(prompts).pick({
  businessId: true,
  name: true,
  content: true,
  active: true,
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  businessId: true,
  customerPhone: true,
  messages: true,
  status: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBusiness = z.infer<typeof insertBusinessSchema>;
export type Business = typeof businesses.$inferSelect;

export type InsertPizza = z.infer<typeof insertPizzaSchema>;
export type Pizza = typeof pizzas.$inferSelect;

export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;
export type MenuItem = typeof menuItems.$inferSelect;

export type InsertPromotion = z.infer<typeof insertPromotionSchema>;
export type Promotion = typeof promotions.$inferSelect;

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

export type InsertPrompt = z.infer<typeof insertPromptSchema>;
export type Prompt = typeof prompts.$inferSelect;

export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;
