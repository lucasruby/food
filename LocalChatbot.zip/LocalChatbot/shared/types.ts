import { ChatCompletionMessageParam } from "openai/resources/chat/completions";

export type Message = {
  role: "user" | "assistant" | "system";
  content: string;
  timestamp?: Date;
};

export type WhatsAppMessage = {
  id: string;
  from: string;
  to: string;
  body: string;
  timestamp: number;
};

export type ChatSession = {
  customerPhone: string;
  customerName?: string;
  messages: Message[];
  orderState?: OrderState;
  lastActivity: Date;
};

export type OrderState = {
  orderCode: string;
  customerName?: string;
  customerAddress?: string;
  items: OrderItem[];
  total: number;
  paymentMethod?: string;
  deliveryMethod?: "delivery" | "pickup";
  status: "cart" | "checkout" | "confirmed" | "completed";
};

export type OrderItem = {
  type: "pizza" | "drink" | "combo" | "other";
  name: string;
  size?: string;
  quantity: number;
  price: number;
  toppings?: string[];
  removedToppings?: string[];
  border?: string;
};

export type MenuCategory = {
  id: string;
  name: string;
  items: MenuItem[];
};

export type MenuItem = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image?: string;
};

export type Pizza = MenuItem & {
  ingredients: string[];
  sizes: PizzaSize[];
  borders?: PizzaBorder[];
};

export type PizzaSize = {
  name: string;
  price: number;
  slices: number;
};

export type PizzaBorder = {
  name: string;
  price: number;
};

export type Promotion = {
  id: string;
  name: string;
  description: string;
  price: number;
  items: PromotionItem[];
  image?: string;
};

export type PromotionItem = {
  type: "pizza" | "drink" | "other";
  name: string;
  quantity: number;
  size?: string;
  border?: string;
};

export type Business = {
  id: string;
  name: string;
  type: string;
  logo?: string;
  address?: string;
  phone?: string;
};

export type BotPrompt = {
  id: string;
  name: string;
  content: string;
  active: boolean;
};

export type WhatsAppInstance = {
  id: string;
  name: string;
  status: "connected" | "disconnected" | "connecting";
  qrCode?: string;
};
