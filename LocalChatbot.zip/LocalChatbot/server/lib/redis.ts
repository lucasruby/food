import { config } from "../config";
import { ChatSession } from "@shared/types";

// Usar um armazenamento em memória enquanto não temos um servidor Redis
// Este é um substituto simples apenas para desenvolvimento
class MemoryStore {
  private store: Map<string, { value: string, expiry?: number }> = new Map();
  
  async set(key: string, value: string, options?: { EX?: number }): Promise<void> {
    let expiry: number | undefined = undefined;
    if (options && options.EX) {
      expiry = Date.now() + (options.EX * 1000);
    }
    this.store.set(key, { value, expiry });
  }
  
  async get(key: string): Promise<string | null> {
    const item = this.store.get(key);
    if (!item) return null;
    
    // Verificar se expirou
    if (item.expiry && item.expiry < Date.now()) {
      this.store.delete(key);
      return null;
    }
    
    return item.value;
  }
  
  async del(key: string): Promise<number> {
    const deleted = this.store.delete(key);
    return deleted ? 1 : 0;
  }
  
  async expire(key: string, seconds: number): Promise<void> {
    const item = this.store.get(key);
    if (item) {
      item.expiry = Date.now() + (seconds * 1000);
      this.store.set(key, item);
    }
  }
}

export const redisClient = new MemoryStore();

console.log("Using memory store for sessions...");

// Session key prefix for chat sessions
const CHAT_SESSION_PREFIX = "chat:session:";
// Session expiration in seconds (24 hours)
const SESSION_EXPIRATION = 24 * 60 * 60;

export async function saveChatSession(
  phone: string,
  session: ChatSession
): Promise<void> {
  await redisClient.set(
    `${CHAT_SESSION_PREFIX}${phone}`,
    JSON.stringify(session),
    {
      EX: SESSION_EXPIRATION
    }
  );
}

export async function getChatSession(
  phone: string
): Promise<ChatSession | null> {
  const data = await redisClient.get(`${CHAT_SESSION_PREFIX}${phone}`);
  if (!data) return null;
  
  try {
    return JSON.parse(data) as ChatSession;
  } catch (error) {
    console.error("Error parsing chat session:", error);
    return null;
  }
}

export async function deleteChatSession(phone: string): Promise<boolean> {
  const result = await redisClient.del(`${CHAT_SESSION_PREFIX}${phone}`);
  return result === 1;
}

export async function updateSessionExpiration(phone: string): Promise<void> {
  await redisClient.expire(`${CHAT_SESSION_PREFIX}${phone}`, SESSION_EXPIRATION);
}
