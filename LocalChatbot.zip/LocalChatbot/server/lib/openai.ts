
import { Message } from "@shared/types";
import { config } from "../config";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: config.openai.apiKey });

export async function generateChatResponse(
  messages: Message[],
  temperature: number = 0.7
): Promise<string> {
  try {
    if (!config.openai.apiKey) {
      console.log("[OpenAI] No API key found, using simulation mode");
      return simulateResponse(messages[messages.length - 1]?.content || "");
    }

    if (!messages || messages.length === 0) {
      console.log("[OpenAI] No messages provided, using simulation");
      return simulateResponse("");
    }

    console.log("[OpenAI] Generating response...");
    const lastMessage = messages[messages.length - 1]?.content || "";
    console.log("[OpenAI] Last message:", lastMessage);
    console.log("[OpenAI] Using API key:", config.openai.apiKey ? "Configured" : "Missing");
    
    const lastUserMessage = messages[messages.length - 1]?.content || "";
    
    if (!messages.length) {
      console.log("No messages provided, using simulation");
      return simulateResponse(lastUserMessage);
    }

    const formattedMessages = messages
      .filter(msg => msg && msg.content && msg.content.trim() !== "")
      .map(msg => ({
        role: msg.role === "user" ? "user" : msg.role === "assistant" ? "assistant" : "system",
        content: msg.content
      }));

    if (!formattedMessages.length) {
      console.log("[OpenAI] No valid messages after filtering, using simulation");
      return simulateResponse(lastUserMessage);
    }

    console.log("[OpenAI] Formatted messages:", JSON.stringify(formattedMessages, null, 2));

    console.log("[OpenAI] Sending request with messages:", JSON.stringify(formattedMessages));
    
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo", // Mudando para um modelo mais estável
      messages: [
        {
          role: "system",
          content: "Você é um atendente da Pizzaria Catalana, especializado em atendimento ao cliente. Você deve: 1) Entender mensagens mesmo com erros de português; 2) Ser capaz de interpretar gírias e linguagem informal; 3) Responder de forma simples e clara, mas sempre cordial; 4) Quando necessário, confirmar o que entendeu para evitar mal-entendidos."
        },
        ...formattedMessages
      ],
      temperature: temperature,
      max_tokens: 500
    });
    
    console.log("[OpenAI] Response received:", response.choices[0]?.message);

    const generatedResponse = response.choices[0]?.message?.content;
    if (!generatedResponse) {
      console.error("Empty response from OpenAI, using simulation");
      return simulateResponse(messages[messages.length - 1]?.content || "");
    }

    console.log("Response generated successfully:", generatedResponse);
    return generatedResponse;
  } catch (error) {
    console.error("Error generating chat response:", error);
    if (error instanceof OpenAI.APIError) {
      console.error("OpenAI API Error:", error.status, error.message);
      // Se for erro de API key, use simulação
      if (error.status === 401) {
        console.log("Invalid API key, using simulation mode");
        return simulateResponse(messages[messages.length - 1]?.content || "");
      }
    }
    // Para outros erros, tente simulação também
    return simulateResponse(messages[messages.length - 1]?.content || "");
  }
}

function simulateResponse(lastUserMessage: string): string {
  const lowerMessage = lastUserMessage.toLowerCase();

  if (lowerMessage.includes("cardápio") || lowerMessage.includes("menu")) {
    return "Temos várias opções deliciosas! Nossa pizza mais popular é a Catalana com calabresa, cebola e pimentão. Também temos as tradicionais como Margherita e Quatro Queijos. Qual você gostaria de experimentar?";
  } else if (lowerMessage.includes("promoção") || lowerMessage.includes("oferta") || lowerMessage.includes("desconto")) {
    return "Temos várias promoções! Nossa oferta especial hoje é a Pizza Grande de Calabresa por R$54,99. Também temos combos promocionais com refrigerante incluso. Quer que eu detalhe alguma promoção específica?";
  } else if (lowerMessage.includes("endereço") || lowerMessage.includes("localização")) {
    return "Estamos localizados na Avenida Principal, 123, Centro. Você pode pedir pelo WhatsApp ou vir nos visitar!";
  } else if (lowerMessage.includes("horário") || lowerMessage.includes("aberto")) {
    return "Funcionamos de terça a domingo, das 18h às 23h. Às segundas-feiras estamos fechados para manutenção.";
  } else if (lowerMessage.includes("entrega") || lowerMessage.includes("delivery")) {
    return "Sim, fazemos entregas! O tempo médio é de 30 a 45 minutos, dependendo da sua localização. A taxa de entrega varia conforme a distância.";
  }

  return "Olá! Como posso ajudar você hoje? Temos um cardápio delicioso de pizzas e várias promoções especiais!";
}

export async function processPizzaOrder(
  messages: Message[],
  orderContext: Record<string, any>
): Promise<{ updatedOrderContext: Record<string, any>; response: string }> {
  try {
    if (!config.openai.apiKey) {
      return {
        updatedOrderContext: orderContext,
        response: simulateResponse(messages[messages.length - 1]?.content || "")
      };
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: `Você é um assistente que processa pedidos de pizza. 
          Analise a conversa e atualize o contexto do pedido.
          O contexto atual do pedido é: ${JSON.stringify(orderContext)}`
        },
        ...messages.map(msg => ({
          role: msg.role === "user" ? "user" : msg.role === "assistant" ? "assistant" : "system",
          content: msg.content
        }))
      ],
      temperature: 0.5,
      max_tokens: 500
    });

    const aiResponse = response.choices[0]?.message?.content;
    if (!aiResponse) {
      throw new Error("Empty response from OpenAI");
    }

    return {
      updatedOrderContext: orderContext,
      response: aiResponse
    };
  } catch (error) {
    console.error("Error processing order:", error);
    return {
      updatedOrderContext: orderContext,
      response: "Desculpe, ocorreu um erro ao processar seu pedido. Por favor, tente novamente."
    };
  }
}

export async function analyzeCustomerIntent(
  message: string
): Promise<{ intent: string; confidence: number }> {
  try {
    if (!config.openai.apiKey) {
      console.log("No API key found, using simulation mode for intent analysis");
      return simulateIntent(message);
    }

    const response = await openai.chat.completions.create({
      model: "gpt-4-turbo-preview",
      messages: [
        {
          role: "system",
          content: "Você é um assistente especializado em analisar a intenção do cliente em um serviço de pizzaria. Analise a mensagem e determine a intenção do cliente. Responda com um JSON contendo a intenção (ver_cardapio, fazer_pedido, pedir_promocao, informacoes, reclamacao, cancelar_pedido, alterar_pedido, outros) e um nível de confiança entre 0 e 1."
        },
        {
          role: "user",
          content: message
        }
      ],
      temperature: 0.3,
      max_tokens: 100,
      response_format: { type: "json_object" }
    });

    const result = response.choices[0]?.message?.content;
    if (!result) {
      throw new Error("Empty response from OpenAI");
    }

    const parsedResponse = JSON.parse(result);
    return {
      intent: parsedResponse.intent || "outros",
      confidence: parsedResponse.confidence || 0.5
    };
  } catch (error) {
    console.error("Error analyzing customer intent:", error);
    return simulateIntent(message);
  }
}

function simulateIntent(message: string): { intent: string; confidence: number } {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes("cardápio") || lowerMessage.includes("menu") || lowerMessage.includes("opções")) {
    return { intent: "ver_cardapio", confidence: 0.9 };
  } else if (lowerMessage.includes("pedir") || lowerMessage.includes("quero") || lowerMessage.includes("pizza de")) {
    return { intent: "fazer_pedido", confidence: 0.8 };
  } else if (lowerMessage.includes("promoção") || lowerMessage.includes("oferta") || lowerMessage.includes("desconto")) {
    return { intent: "pedir_promocao", confidence: 0.9 };
  } else if (lowerMessage.includes("endereço") || lowerMessage.includes("horário") || lowerMessage.includes("aberto")) {
    return { intent: "informacoes", confidence: 0.8 };
  } else if (lowerMessage.includes("reclamação") || lowerMessage.includes("problema") || lowerMessage.includes("ruim")) {
    return { intent: "reclamacao", confidence: 0.8 };
  } else if (lowerMessage.includes("cancelar") || lowerMessage.includes("desistir")) {
    return { intent: "cancelar_pedido", confidence: 0.8 };
  } else if (lowerMessage.includes("mudar") || lowerMessage.includes("alterar") || lowerMessage.includes("trocar")) {
    return { intent: "alterar_pedido", confidence: 0.8 };
  }
  
  return { intent: "outros", confidence: 0.5 };
}
