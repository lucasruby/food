// Importações (comentadas para usar o modo mock)
// import { create, Whatsapp, Message as VenomMessage } from "venom-bot";
import { storage } from "../storage";
import { generateChatResponse, analyzeCustomerIntent, processPizzaOrder } from "./openai";
import { Message, ChatSession, OrderState } from "@shared/types";
import { saveChatSession, getChatSession, updateSessionExpiration } from "./redis";
import { randomUUID } from "crypto";

// Interface mock para o cliente WhatsApp
interface MockWhatsapp {
  sendText: (to: string, message: string) => Promise<any>;
  logout: () => Promise<void>;
  onMessage: (callback: Function) => void;
}

// Cliente mock do WhatsApp
let client: MockWhatsapp | null = null;

export async function initWhatsApp() {
  try {
    console.log("Initializing WhatsApp client (MOCK MODE)...");
    
    // Criar um cliente mock em vez de inicializar o verdadeiro
    client = {
      sendText: async (to: string, message: string) => {
        console.log(`[MOCK] Message sent to ${to}: ${message}`);
        return { status: 'success' };
      },
      logout: async () => {
        console.log('[MOCK] WhatsApp client logged out');
      },
      onMessage: (callback: Function) => {
        console.log('[MOCK] Message handler registered');
      }
    };
    
    console.log("WhatsApp client initialized successfully (MOCK MODE)");
    
    client.onMessage(handleMessage);
    
    return {
      status: "success",
      message: "WhatsApp initialized successfully (MOCK MODE)"
    };
  } catch (error) {
    console.error("Error initializing WhatsApp client:", error);
    return {
      status: "error",
      message: `Failed to initialize WhatsApp: ${error}`
    };
  }
}

// Interface para mensagem mock do WhatsApp
interface MockMessage {
  body: string;
  from: string;
  isGroupMsg?: boolean;
}

async function handleMessage(message: MockMessage) {
  // Ignore group messages and empty messages
  if (!message.body || message.isGroupMsg) return;
  
  const customerPhone = message.from;
  
  try {
    // Get or create chat session
    let session = await getChatSession(customerPhone);
    
    if (!session) {
      // Get business information (using default business for now)
      const business = await storage.getBusiness(1);
      
      if (!business) {
        console.error("Business not found");
        return;
      }
      
      // Get active prompt for the business
      const prompt = await storage.getActivePromptByBusiness(1);
      
      if (!prompt) {
        console.error("No active prompt found for business");
        return;
      }
      
      // Create new session
      const systemPrompt = prompt.content
        .replace("{{ storeName }}", business.name)
        .replace("{{ orderCode }}", `ORD-${randomUUID().slice(0, 6)}`);
      
      session = {
        customerPhone,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "assistant", content: `Olá! Bem-vindo à ${business.name} 🍕 Como posso ajudar você hoje?` }
        ],
        orderState: {
          orderCode: `ORD-${randomUUID().slice(0, 6)}`,
          items: [],
          total: 0,
          status: "cart"
        },
        lastActivity: new Date()
      };
      
      // Send welcome message
      await client?.sendText(
        customerPhone,
        `Olá! Bem-vindo à ${business.name} 🍕 Como posso ajudar você hoje?`
      );
    }
    
    // Add user message to session
    session.messages.push({
      role: "user",
      content: message.body,
      timestamp: new Date()
    });
    
    // Analyze customer intent
    const { intent, confidence } = await analyzeCustomerIntent(message.body);
    
    // Process the message based on intent
    let response = "";
    
    if (intent === "ver_cardapio" && confidence > 0.7) {
      // Get menu items
      const pizzas = await storage.getPizzasByBusiness(1);
      const drinks = await storage.getMenuItemsByBusiness(1);
      const promotions = await storage.getPromotionsByBusiness(1);
      
      // Format menu message
      response = formatMenuMessage(pizzas, drinks, promotions);
    } else if (intent === "fazer_pedido" || session.orderState?.status === "cart") {
      // Process order with OpenAI
      const { updatedOrderContext, response: aiResponse } = await processPizzaOrder(
        session.messages,
        session.orderState || {}
      );
      
      // Update order state in session
      session.orderState = updatedOrderContext as OrderState;
      response = aiResponse;
    } else {
      // Generate normal response from OpenAI
      response = await generateChatResponse(session.messages);
    }
    
    // Add assistant response to session
    session.messages.push({
      role: "assistant",
      content: response,
      timestamp: new Date()
    });
    
    // Update session last activity
    session.lastActivity = new Date();
    
    // Save updated session
    await saveChatSession(customerPhone, session);
    
    // Send response to user
    await client?.sendText(customerPhone, response);
    
    // Update session expiration
    await updateSessionExpiration(customerPhone);
  } catch (error) {
    console.error("Error handling message:", error);
    
    // Send error message to user
    await client?.sendText(
      customerPhone,
      "Desculpe, ocorreu um erro ao processar sua mensagem. Por favor, tente novamente mais tarde."
    );
  }
}

function formatMenuMessage(pizzas: any[], drinks: any[], promotions: any[]): string {
  let message = `Claro! Ficarei feliz em compartilhar nosso cardápio com você. Temos várias opções deliciosas!\n\n`;
  
  message += `🍕 CARDÁPIO DE PIZZAS:\n\n`;
  
  message += `Tamanhos disponíveis:\n`;
  message += `- Pizza Grande (8 fatias) - R$54,99\n`;
  message += `- Pizza Gigante (12 fatias) - R$64,99\n\n`;
  
  message += `Sabores Tradicionais:\n`;
  pizzas.forEach(pizza => {
    message += `- ${pizza.name} (${pizza.description})\n`;
  });
  
  message += `\nBordas disponíveis:\n`;
  message += `- Catupiry\n`;
  message += `- Cheddar\n`;
  message += `- Chocolate\n\n`;
  
  message += `🥤 BEBIDAS:\n`;
  drinks.forEach(drink => {
    message += `- ${drink.name} - R$${drink.price.toFixed(2)}\n`;
  });
  
  message += `\n🔥 PROMOÇÕES DO DIA:\n\n`;
  promotions.forEach(promotion => {
    message += `${promotion.name} - R$${promotion.price.toFixed(2)}\n`;
    message += `${promotion.description}\n\n`;
  });
  
  message += `Gostaria de fazer um pedido ou tem alguma dúvida?`;
  
  return message;
}

export function getWhatsAppStatus(): { status: string; qrCode?: string } {
  if (!client) {
    return { status: "disconnected" };
  }
  
  // In a real implementation, we would get the QR code if available
  return { status: "connected" };
}

export async function logoutWhatsApp(): Promise<boolean> {
  if (client) {
    try {
      await client.logout();
      client = null;
      return true;
    } catch (error) {
      console.error("Error logging out of WhatsApp:", error);
      return false;
    }
  }
  return false;
}

export async function restartWhatsApp(): Promise<any> {
  if (client) {
    await logoutWhatsApp();
  }
  return initWhatsApp();
}
