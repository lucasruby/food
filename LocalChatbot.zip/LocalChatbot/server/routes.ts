import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertBusinessSchema, 
  insertPizzaSchema, 
  insertMenuItemSchema, 
  insertPromotionSchema,
  insertPromptSchema,
  insertOrderSchema,
  insertCustomerSchema
} from "@shared/schema";
import { initWhatsApp, getWhatsAppStatus, logoutWhatsApp, restartWhatsApp } from "./lib/whatsapp";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // API routes
  app.get("/api/health", (req: Request, res: Response) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // WhatsApp routes
  app.get("/api/whatsapp/status", async (req: Request, res: Response) => {
    const status = getWhatsAppStatus();
    res.json(status);
  });

  app.post("/api/whatsapp/init", async (req: Request, res: Response) => {
    const result = await initWhatsApp();
    res.json(result);
  });

  app.post("/api/whatsapp/logout", async (req: Request, res: Response) => {
    const success = await logoutWhatsApp();
    res.json({ success });
  });

  app.post("/api/whatsapp/restart", async (req: Request, res: Response) => {
    const result = await restartWhatsApp();
    res.json(result);
  });

  // Business routes
  app.get("/api/businesses", async (req: Request, res: Response) => {
    const businesses = await storage.getBusinesses();
    res.json(businesses);
  });

  app.get("/api/businesses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const business = await storage.getBusiness(id);
    
    if (!business) {
      return res.status(404).json({ message: "Business not found" });
    }
    
    res.json(business);
  });

  app.post("/api/businesses", async (req: Request, res: Response) => {
    try {
      const validatedData = insertBusinessSchema.parse(req.body);
      const business = await storage.createBusiness(validatedData);
      res.status(201).json(business);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid business data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create business" });
    }
  });

  app.put("/api/businesses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertBusinessSchema.partial().parse(req.body);
      const business = await storage.updateBusiness(id, validatedData);
      
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      res.json(business);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid business data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update business" });
    }
  });

  app.delete("/api/businesses/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteBusiness(id);
    
    if (!success) {
      return res.status(404).json({ message: "Business not found" });
    }
    
    res.status(204).send();
  });

  // Pizza routes
  app.get("/api/businesses/:businessId/pizzas", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const pizzas = await storage.getPizzasByBusiness(businessId);
    res.json(pizzas);
  });

  app.post("/api/pizzas", async (req: Request, res: Response) => {
    try {
      const validatedData = insertPizzaSchema.parse(req.body);
      const pizza = await storage.createPizza(validatedData);
      res.status(201).json(pizza);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pizza data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create pizza" });
    }
  });

  app.put("/api/pizzas/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPizzaSchema.partial().parse(req.body);
      const pizza = await storage.updatePizza(id, validatedData);
      
      if (!pizza) {
        return res.status(404).json({ message: "Pizza not found" });
      }
      
      res.json(pizza);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid pizza data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update pizza" });
    }
  });

  app.delete("/api/pizzas/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const success = await storage.deletePizza(id);
    
    if (!success) {
      return res.status(404).json({ message: "Pizza not found" });
    }
    
    res.status(204).send();
  });

  // Menu Item routes
  app.get("/api/businesses/:businessId/menuitems", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const menuItems = await storage.getMenuItemsByBusiness(businessId);
    res.json(menuItems);
  });

  app.post("/api/menuitems", async (req: Request, res: Response) => {
    try {
      const validatedData = insertMenuItemSchema.parse(req.body);
      const menuItem = await storage.createMenuItem(validatedData);
      res.status(201).json(menuItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid menu item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create menu item" });
    }
  });

  app.put("/api/menuitems/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertMenuItemSchema.partial().parse(req.body);
      const menuItem = await storage.updateMenuItem(id, validatedData);
      
      if (!menuItem) {
        return res.status(404).json({ message: "Menu item not found" });
      }
      
      res.json(menuItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid menu item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update menu item" });
    }
  });

  app.delete("/api/menuitems/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const success = await storage.deleteMenuItem(id);
    
    if (!success) {
      return res.status(404).json({ message: "Menu item not found" });
    }
    
    res.status(204).send();
  });

  // Promotion routes
  app.get("/api/businesses/:businessId/promotions", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const promotions = await storage.getPromotionsByBusiness(businessId);
    res.json(promotions);
  });

  app.post("/api/promotions", async (req: Request, res: Response) => {
    try {
      const validatedData = insertPromotionSchema.parse(req.body);
      const promotion = await storage.createPromotion(validatedData);
      res.status(201).json(promotion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid promotion data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create promotion" });
    }
  });

  app.put("/api/promotions/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPromotionSchema.partial().parse(req.body);
      const promotion = await storage.updatePromotion(id, validatedData);
      
      if (!promotion) {
        return res.status(404).json({ message: "Promotion not found" });
      }
      
      res.json(promotion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid promotion data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update promotion" });
    }
  });

  app.delete("/api/promotions/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const success = await storage.deletePromotion(id);
    
    if (!success) {
      return res.status(404).json({ message: "Promotion not found" });
    }
    
    res.status(204).send();
  });

  // Prompt routes
  app.get("/api/businesses/:businessId/prompts", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const prompts = await storage.getPromptsByBusiness(businessId);
    res.json(prompts);
  });

  app.get("/api/businesses/:businessId/prompts/active", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const prompt = await storage.getActivePromptByBusiness(businessId);
    
    if (!prompt) {
      return res.status(404).json({ message: "No active prompt found" });
    }
    
    res.json(prompt);
  });

  app.post("/api/prompts", async (req: Request, res: Response) => {
    try {
      const validatedData = insertPromptSchema.parse(req.body);
      const prompt = await storage.createPrompt(validatedData);
      res.status(201).json(prompt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prompt data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create prompt" });
    }
  });

  app.put("/api/prompts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPromptSchema.partial().parse(req.body);
      const prompt = await storage.updatePrompt(id, validatedData);
      
      if (!prompt) {
        return res.status(404).json({ message: "Prompt not found" });
      }
      
      res.json(prompt);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid prompt data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update prompt" });
    }
  });

  app.delete("/api/prompts/:id", async (req: Request, res: Response) => {
    const id = parseInt(req.params.id);
    const success = await storage.deletePrompt(id);
    
    if (!success) {
      return res.status(404).json({ message: "Prompt not found" });
    }
    
    res.status(204).send();
  });

  // Order routes
  app.get("/api/businesses/:businessId/orders", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const orders = await storage.getOrdersByBusiness(businessId);
    res.json(orders);
  });

  app.post("/api/orders", async (req: Request, res: Response) => {
    try {
      const validatedData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(validatedData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.put("/api/orders/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertOrderSchema.partial().parse(req.body);
      const order = await storage.updateOrder(id, validatedData);
      
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      
      res.json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update order" });
    }
  });

  // Customer routes
  app.get("/api/businesses/:businessId/customers", async (req: Request, res: Response) => {
    const businessId = parseInt(req.params.businessId);
    const customers = await storage.getCustomersByBusiness(businessId);
    res.json(customers);
  });

  app.post("/api/customers", async (req: Request, res: Response) => {
    try {
      const validatedData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(validatedData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create customer" });
    }
  });

  app.put("/api/customers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertCustomerSchema.partial().parse(req.body);
      const customer = await storage.updateCustomer(id, validatedData);
      
      if (!customer) {
        return res.status(404).json({ message: "Customer not found" });
      }
      
      res.json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid customer data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update customer" });
    }
  });

  // Initialize WhatsApp on server start
  initWhatsApp().catch(console.error);

  return httpServer;
}
