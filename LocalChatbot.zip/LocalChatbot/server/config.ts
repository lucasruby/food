// Configurações para a aplicação

export const config = {
  redis: {
    host: process.env.REDIS_HOST || "localhost",
    port: parseInt(process.env.REDIS_PORT || "6379"),
    db: parseInt(process.env.REDIS_DB || "0")
  },
  openai: {
    apiKey: process.env.OPENAI_API_KEY || "",
    model: "gpt-4-turbo-preview" 
  },
  server: {
    port: parseInt(process.env.PORT || "3000"),
    host: process.env.HOST || "0.0.0.0"
  }
};