import { 
  User, InsertUser, 
  Business, InsertBusiness,
  Pizza, InsertPizza,
  MenuItem, InsertMenuItem,
  Promotion, InsertPromotion,
  Order, InsertOrder,
  Customer, InsertCustomer,
  Prompt, InsertPrompt,
  Conversation, InsertConversation
} from "@shared/schema";
import { ChatSession, Message, OrderState } from "@shared/types";

// Storage interface for all entities
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Businesses
  getBusiness(id: number): Promise<Business | undefined>;
  getBusinesses(): Promise<Business[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: number, business: Partial<Business>): Promise<Business | undefined>;
  deleteBusiness(id: number): Promise<boolean>;

  // Pizzas
  getPizza(id: number): Promise<Pizza | undefined>;
  getPizzasByBusiness(businessId: number): Promise<Pizza[]>;
  createPizza(pizza: InsertPizza): Promise<Pizza>;
  updatePizza(id: number, pizza: Partial<Pizza>): Promise<Pizza | undefined>;
  deletePizza(id: number): Promise<boolean>;

  // Menu Items
  getMenuItem(id: number): Promise<MenuItem | undefined>;
  getMenuItemsByBusiness(businessId: number): Promise<MenuItem[]>;
  createMenuItem(menuItem: InsertMenuItem): Promise<MenuItem>;
  updateMenuItem(id: number, menuItem: Partial<MenuItem>): Promise<MenuItem | undefined>;
  deleteMenuItem(id: number): Promise<boolean>;

  // Promotions
  getPromotion(id: number): Promise<Promotion | undefined>;
  getPromotionsByBusiness(businessId: number): Promise<Promotion[]>;
  createPromotion(promotion: InsertPromotion): Promise<Promotion>;
  updatePromotion(id: number, promotion: Partial<Promotion>): Promise<Promotion | undefined>;
  deletePromotion(id: number): Promise<boolean>;

  // Orders
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByBusiness(businessId: number): Promise<Order[]>;
  getOrdersByCustomer(customerPhone: string): Promise<Order[]>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, order: Partial<Order>): Promise<Order | undefined>;
  deleteOrder(id: number): Promise<boolean>;

  // Customers
  getCustomer(id: number): Promise<Customer | undefined>;
  getCustomerByPhone(phone: string): Promise<Customer | undefined>;
  getCustomersByBusiness(businessId: number): Promise<Customer[]>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, customer: Partial<Customer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;

  // Prompts
  getPrompt(id: number): Promise<Prompt | undefined>;
  getPromptsByBusiness(businessId: number): Promise<Prompt[]>;
  getActivePromptByBusiness(businessId: number): Promise<Prompt | undefined>;
  createPrompt(prompt: InsertPrompt): Promise<Prompt>;
  updatePrompt(id: number, prompt: Partial<Prompt>): Promise<Prompt | undefined>;
  deletePrompt(id: number): Promise<boolean>;

  // Conversations
  getConversation(id: number): Promise<Conversation | undefined>;
  getConversationByCustomer(customerPhone: string, businessId: number): Promise<Conversation | undefined>;
  getConversationsByBusiness(businessId: number): Promise<Conversation[]>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  updateConversation(id: number, conversation: Partial<Conversation>): Promise<Conversation | undefined>;
  deleteConversation(id: number): Promise<boolean>;

  // Chat Sessions
  getChatSession(customerPhone: string): Promise<ChatSession | undefined>;
  saveChatSession(customerPhone: string, session: ChatSession): Promise<void>;
  deleteChatSession(customerPhone: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private businesses: Map<number, Business>;
  private pizzas: Map<number, Pizza>;
  private menuItems: Map<number, MenuItem>;
  private promotions: Map<number, Promotion>;
  private orders: Map<number, Order>;
  private customers: Map<number, Customer>;
  private prompts: Map<number, Prompt>;
  private conversations: Map<number, Conversation>;
  private chatSessions: Map<string, ChatSession>;
  
  private currentIds: {
    users: number;
    businesses: number;
    pizzas: number;
    menuItems: number;
    promotions: number;
    orders: number;
    customers: number;
    prompts: number;
    conversations: number;
  };

  constructor() {
    this.users = new Map();
    this.businesses = new Map();
    this.pizzas = new Map();
    this.menuItems = new Map();
    this.promotions = new Map();
    this.orders = new Map();
    this.customers = new Map();
    this.prompts = new Map();
    this.conversations = new Map();
    this.chatSessions = new Map();
    
    this.currentIds = {
      users: 1,
      businesses: 1,
      pizzas: 1,
      menuItems: 1,
      promotions: 1,
      orders: 1,
      customers: 1,
      prompts: 1,
      conversations: 1
    };

    // Create sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Sample business
    const business: InsertBusiness = {
      name: "Pizzaria Catalana",
      type: "pizzaria",
      address: "Rua Abaeté, 123, Centro, São José dos Campos, SP",
      phone: "+5512999999999"
    };
    this.createBusiness(business);

    // Sample pizzas
    const pizzas: InsertPizza[] = [
      {
        businessId: 1,
        name: "À Moda",
        description: "molho, mussarela, presunto, cebola, pimentão, tomate, azeitona",
        ingredients: ["molho", "mussarela", "presunto", "cebola", "pimentão", "tomate", "azeitona"],
        price: 54.99,
        size: "Grande",
        category: "Tradicional",
        active: true
      },
      {
        businessId: 1,
        name: "Bauru",
        description: "molho, mussarela, presunto, tomate, oregano",
        ingredients: ["molho", "mussarela", "presunto", "tomate", "oregano"],
        price: 54.99,
        size: "Grande",
        category: "Tradicional",
        active: true
      },
      {
        businessId: 1,
        name: "Bacon",
        description: "molho, mussarela, bacon, cebola",
        ingredients: ["molho", "mussarela", "bacon", "cebola"],
        price: 54.99,
        size: "Grande",
        category: "Tradicional",
        active: true
      },
      {
        businessId: 1,
        name: "Catalana",
        description: "molho, mussarela, calabresa, bacon, cebola, azeitona",
        ingredients: ["molho", "mussarela", "calabresa", "bacon", "cebola", "azeitona"],
        price: 54.99,
        size: "Grande",
        category: "Tradicional",
        active: true
      },
      {
        businessId: 1,
        name: "Goiana",
        description: "molho, mussarela, calabresa, milho, azeitona",
        ingredients: ["molho", "mussarela", "calabresa", "milho", "azeitona"],
        price: 54.99,
        size: "Grande",
        category: "Tradicional",
        active: true
      }
    ];

    pizzas.forEach(pizza => this.createPizza(pizza));

    // Sample menu items (drinks)
    const drinks: InsertMenuItem[] = [
      {
        businessId: 1,
        name: "Sukita 2L",
        description: "Refrigerante Sukita 2L",
        price: 12.99,
        category: "Bebidas",
        active: true
      },
      {
        businessId: 1,
        name: "Coca-Cola 1,5L",
        description: "Refrigerante Coca-Cola 1,5L",
        price: 10.99,
        category: "Bebidas",
        active: true
      },
      {
        businessId: 1,
        name: "Guaraná 1,5L",
        description: "Refrigerante Guaraná 1,5L",
        price: 10.99,
        category: "Bebidas",
        active: true
      },
      {
        businessId: 1,
        name: "Fanta 1,5L",
        description: "Refrigerante Fanta 1,5L",
        price: 10.99,
        category: "Bebidas",
        active: true
      },
      {
        businessId: 1,
        name: "Água mineral 500ml",
        description: "Água mineral sem gás 500ml",
        price: 4.99,
        category: "Bebidas",
        active: true
      }
    ];

    drinks.forEach(drink => this.createMenuItem(drink));

    // Sample promotions
    const promotions: InsertPromotion[] = [
      {
        businessId: 1,
        name: "COMBO PREMIUM",
        description: "Qualquer pizza grande do cardápio com borda de catupiry + refrigerante 1,5L",
        price: 64.99,
        items: [
          { type: "pizza", size: "Grande", border: "Catupiry", quantity: 1 },
          { type: "drink", name: "Refrigerante 1,5L", quantity: 1 }
        ],
        active: true
      },
      {
        businessId: 1,
        name: "COMBO MASTER",
        description: "Pizza GG 3 sabores com borda de catupiry + refrigerante 1,5L",
        price: 74.99,
        items: [
          { type: "pizza", size: "Gigante", sabores: 3, border: "Catupiry", quantity: 1 },
          { type: "drink", name: "Refrigerante 1,5L", quantity: 1 }
        ],
        active: true
      },
      {
        businessId: 1,
        name: "COMBO ESFIHAS",
        description: "8 unidades de esfihas (sabores variados)",
        price: 44.99,
        items: [
          { type: "other", name: "Esfihas", quantity: 8 }
        ],
        active: true
      }
    ];

    promotions.forEach(promotion => this.createPromotion(promotion));

    // Sample prompt
    const promptContent = `Você é uma assistente virtual de atendimento de uma pizzaria chamada {{ storeName }}. Você deve ser educada, atenciosa, amigável, cordial e muito paciente.

Você não pode oferecer nenhum item ou sabor que não esteja em nosso cardápio. Siga estritamente as listas de opções.

O código do pedido é: {{ orderCode }}

O roteiro de atendimento é:

1. Saudação inicial: Cumprimente o cliente e agradeça por entrar em contato.
2. Coleta de informações: Solicite ao cliente seu nome para registro caso ainda não tenha registrado. Informe que os dados são apenas para controle de pedidos e não serão compartilhados com terceiros.
3. Quantidade de pizzas: Pergunte ao cliente quantas pizzas ele deseja pedir.
4. Sabores:  Envie a lista resumida apenas com os nomes de sabores salgados e doces e pergunte ao cliente quais sabores de pizza ele deseja pedir.
4.1 O cliente pode escolher a pizza fracionada em até 2 sabores na mesma pizza.
4.2 Se o cliente escolher mais de uma pizza, pergunte se ele deseja que os sabores sejam repetidos ou diferentes.
4.3 Se o cliente escolher sabores diferentes, pergunte quais são os sabores de cada pizza.
4.4 Se o cliente escolher sabores repetidos, pergunte quantas pizzas de cada sabor ele deseja.
4.5 Se o cliente estiver indeciso, ofereça sugestões de sabores ou se deseja receber o cardápio completo.
4.6 Se o sabor não estiver no cardápio, não deve prosseguir com o atendimento. Nesse caso informe que o sabor não está disponível e agradeça o cliente.
5. Tamanho: Pergunte ao cliente qual o tamanho das pizzas.
5.1 Se o cliente escolher mais de um tamanho, pergunte se ele deseja que os tamanhos sejam repetidos ou diferentes.
5.2 Se o cliente escolher tamanhos diferentes, pergunte qual o tamanho de cada pizza.
5.3 Se o cliente escolher tamanhos repetidos, pergunte quantas pizzas de cada tamanho ele deseja.
5.4 Se o cliente estiver indeciso, ofereça sugestões de tamanhos. Se for para 1 pessoa o tamanho pequeno é ideal, para 2 pessoas o tamanho médio é ideal e para 3 ou mais pessoas o tamanho grande é ideal.
6. Ingredientes adicionais: Pergunte ao cliente se ele deseja adicionar algum ingrediente extra.
6.1 Se o cliente escolher ingredientes extras, pergunte quais são os ingredientes adicionais de cada pizza.
6.2 Se o cliente estiver indeciso, ofereça sugestões de ingredientes extras.
7. Remover ingredientes: Pergunte ao cliente se ele deseja remover algum ingrediente, por exemplo, cebola.
7.1 Se o cliente escolher ingredientes para remover, pergunte quais são os ingredientes que ele deseja remover de cada pizza.
7.2 Não é possível remover ingredientes que não existam no cardápio.
8. Borda: Pergunte ao cliente se ele deseja borda recheada.
8.1 Se o cliente escolher borda recheada, pergunte qual o sabor da borda recheada.
8.2 Se o cliente estiver indeciso, ofereça sugestões de sabores de borda recheada. Uma dica é oferecer a borda como sobremesa com sabor de chocolate.
9. Bebidas: Pergunte ao cliente se ele deseja pedir alguma bebida.
9.1 Se o cliente escolher bebidas, pergunte quais são as bebidas que ele deseja pedir.
9.2 Se o cliente estiver indeciso, ofereça sugestões de bebidas.
10.  Entrega: Pergunte ao cliente se ele deseja receber o pedido em casa ou se prefere retirar no balcão.
10.1 Se o cliente escolher entrega, pergunte qual o endereço de entrega. O endereço deverá conter Rua, Número, Bairro e CEP.
10.2 Os CEPs de 12.220-000 até 12.330-000 possuem uma taxa de entrega de R$ 10,00.
10.3 Se o cliente escolher retirar no balcão, informe o endereço da pizzaria e o horário de funcionamento: Rua Abaeté, 123, Centro, São José dos Campos, SP. Horário de funcionamento: 18h às 23h.
11.  Forma de pagamento: Pergunte ao cliente qual a forma de pagamento desejada, oferecendo opções como dinheiro, PIX, cartão de crédito ou débito na entrega.
11.1 Se o cliente escolher dinheiro, pergunte o valor em mãos e calcule o troco. O valor informado não pode ser menor que o valor total do pedido.
11.2 Se o cliente escolher PIX, forneça a chave PIX CNPJ: 1234
11.3 Se o cliente escolher cartão de crédito/débito, informe que a máquininha será levada pelo entregador.
12.  Mais alguma coisa? Pergunte ao cliente se ele deseja pedir mais alguma coisa.
12.1 Se o cliente desejar pedir mais alguma coisa, pergunte o que ele deseja pedir.
12.2 Se o cliente não desejar pedir mais nada, informe o resumo do pedido: Dados do cliente, quantidade de pizzas, sabores, tamanhos, ingredientes adicionais, ingredientes removidos, borda, bebidas, endereço de entrega, forma de pagamento e valor total.`;

    const prompt: InsertPrompt = {
      businessId: 1,
      name: "Default",
      content: promptContent,
      active: true
    };

    this.createPrompt(prompt);
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Businesses
  async getBusiness(id: number): Promise<Business | undefined> {
    return this.businesses.get(id);
  }

  async getBusinesses(): Promise<Business[]> {
    return Array.from(this.businesses.values());
  }

  async createBusiness(insertBusiness: InsertBusiness): Promise<Business> {
    const id = this.currentIds.businesses++;
    const createdAt = new Date();
    const business: Business = { ...insertBusiness, id, createdAt };
    this.businesses.set(id, business);
    return business;
  }

  async updateBusiness(id: number, business: Partial<Business>): Promise<Business | undefined> {
    const existingBusiness = this.businesses.get(id);
    if (!existingBusiness) {
      return undefined;
    }
    const updatedBusiness = { ...existingBusiness, ...business };
    this.businesses.set(id, updatedBusiness);
    return updatedBusiness;
  }

  async deleteBusiness(id: number): Promise<boolean> {
    return this.businesses.delete(id);
  }

  // Pizzas
  async getPizza(id: number): Promise<Pizza | undefined> {
    return this.pizzas.get(id);
  }

  async getPizzasByBusiness(businessId: number): Promise<Pizza[]> {
    return Array.from(this.pizzas.values()).filter(
      (pizza) => pizza.businessId === businessId,
    );
  }

  async createPizza(insertPizza: InsertPizza): Promise<Pizza> {
    const id = this.currentIds.pizzas++;
    const pizza: Pizza = { ...insertPizza, id };
    this.pizzas.set(id, pizza);
    return pizza;
  }

  async updatePizza(id: number, pizza: Partial<Pizza>): Promise<Pizza | undefined> {
    const existingPizza = this.pizzas.get(id);
    if (!existingPizza) {
      return undefined;
    }
    const updatedPizza = { ...existingPizza, ...pizza };
    this.pizzas.set(id, updatedPizza);
    return updatedPizza;
  }

  async deletePizza(id: number): Promise<boolean> {
    return this.pizzas.delete(id);
  }

  // Menu Items
  async getMenuItem(id: number): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }

  async getMenuItemsByBusiness(businessId: number): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values()).filter(
      (menuItem) => menuItem.businessId === businessId,
    );
  }

  async createMenuItem(insertMenuItem: InsertMenuItem): Promise<MenuItem> {
    const id = this.currentIds.menuItems++;
    const menuItem: MenuItem = { ...insertMenuItem, id };
    this.menuItems.set(id, menuItem);
    return menuItem;
  }

  async updateMenuItem(id: number, menuItem: Partial<MenuItem>): Promise<MenuItem | undefined> {
    const existingMenuItem = this.menuItems.get(id);
    if (!existingMenuItem) {
      return undefined;
    }
    const updatedMenuItem = { ...existingMenuItem, ...menuItem };
    this.menuItems.set(id, updatedMenuItem);
    return updatedMenuItem;
  }

  async deleteMenuItem(id: number): Promise<boolean> {
    return this.menuItems.delete(id);
  }

  // Promotions
  async getPromotion(id: number): Promise<Promotion | undefined> {
    return this.promotions.get(id);
  }

  async getPromotionsByBusiness(businessId: number): Promise<Promotion[]> {
    return Array.from(this.promotions.values()).filter(
      (promotion) => promotion.businessId === businessId,
    );
  }

  async createPromotion(insertPromotion: InsertPromotion): Promise<Promotion> {
    const id = this.currentIds.promotions++;
    const promotion: Promotion = { ...insertPromotion, id };
    this.promotions.set(id, promotion);
    return promotion;
  }

  async updatePromotion(id: number, promotion: Partial<Promotion>): Promise<Promotion | undefined> {
    const existingPromotion = this.promotions.get(id);
    if (!existingPromotion) {
      return undefined;
    }
    const updatedPromotion = { ...existingPromotion, ...promotion };
    this.promotions.set(id, updatedPromotion);
    return updatedPromotion;
  }

  async deletePromotion(id: number): Promise<boolean> {
    return this.promotions.delete(id);
  }

  // Orders
  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersByBusiness(businessId: number): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.businessId === businessId,
    );
  }

  async getOrdersByCustomer(customerPhone: string): Promise<Order[]> {
    return Array.from(this.orders.values()).filter(
      (order) => order.customerPhone === customerPhone,
    );
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.currentIds.orders++;
    const createdAt = new Date();
    const order: Order = { ...insertOrder, id, createdAt };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: number, order: Partial<Order>): Promise<Order | undefined> {
    const existingOrder = this.orders.get(id);
    if (!existingOrder) {
      return undefined;
    }
    const updatedOrder = { ...existingOrder, ...order };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async deleteOrder(id: number): Promise<boolean> {
    return this.orders.delete(id);
  }

  // Customers
  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async getCustomerByPhone(phone: string): Promise<Customer | undefined> {
    return Array.from(this.customers.values()).find(
      (customer) => customer.phone === phone,
    );
  }

  async getCustomersByBusiness(businessId: number): Promise<Customer[]> {
    return Array.from(this.customers.values()).filter(
      (customer) => customer.businessId === businessId,
    );
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = this.currentIds.customers++;
    const createdAt = new Date();
    const customer: Customer = { ...insertCustomer, id, orderCount: 0, createdAt };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: number, customer: Partial<Customer>): Promise<Customer | undefined> {
    const existingCustomer = this.customers.get(id);
    if (!existingCustomer) {
      return undefined;
    }
    const updatedCustomer = { ...existingCustomer, ...customer };
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }

  async deleteCustomer(id: number): Promise<boolean> {
    return this.customers.delete(id);
  }

  // Prompts
  async getPrompt(id: number): Promise<Prompt | undefined> {
    return this.prompts.get(id);
  }

  async getPromptsByBusiness(businessId: number): Promise<Prompt[]> {
    return Array.from(this.prompts.values()).filter(
      (prompt) => prompt.businessId === businessId,
    );
  }

  async getActivePromptByBusiness(businessId: number): Promise<Prompt | undefined> {
    return Array.from(this.prompts.values()).find(
      (prompt) => prompt.businessId === businessId && prompt.active,
    );
  }

  async createPrompt(insertPrompt: InsertPrompt): Promise<Prompt> {
    const id = this.currentIds.prompts++;
    const createdAt = new Date();
    const prompt: Prompt = { ...insertPrompt, id, createdAt };
    this.prompts.set(id, prompt);
    return prompt;
  }

  async updatePrompt(id: number, prompt: Partial<Prompt>): Promise<Prompt | undefined> {
    const existingPrompt = this.prompts.get(id);
    if (!existingPrompt) {
      return undefined;
    }
    const updatedPrompt = { ...existingPrompt, ...prompt };
    this.prompts.set(id, updatedPrompt);
    return updatedPrompt;
  }

  async deletePrompt(id: number): Promise<boolean> {
    return this.prompts.delete(id);
  }

  // Conversations
  async getConversation(id: number): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }

  async getConversationByCustomer(customerPhone: string, businessId: number): Promise<Conversation | undefined> {
    return Array.from(this.conversations.values()).find(
      (conversation) => 
        conversation.customerPhone === customerPhone && 
        conversation.businessId === businessId &&
        conversation.status === "active"
    );
  }

  async getConversationsByBusiness(businessId: number): Promise<Conversation[]> {
    return Array.from(this.conversations.values()).filter(
      (conversation) => conversation.businessId === businessId,
    );
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = this.currentIds.conversations++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const conversation: Conversation = { ...insertConversation, id, createdAt, updatedAt };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async updateConversation(id: number, conversation: Partial<Conversation>): Promise<Conversation | undefined> {
    const existingConversation = this.conversations.get(id);
    if (!existingConversation) {
      return undefined;
    }
    const updatedAt = new Date();
    const updatedConversation = { ...existingConversation, ...conversation, updatedAt };
    this.conversations.set(id, updatedConversation);
    return updatedConversation;
  }

  async deleteConversation(id: number): Promise<boolean> {
    return this.conversations.delete(id);
  }

  // Chat Sessions
  async getChatSession(customerPhone: string): Promise<ChatSession | undefined> {
    return this.chatSessions.get(customerPhone);
  }

  async saveChatSession(customerPhone: string, session: ChatSession): Promise<void> {
    this.chatSessions.set(customerPhone, session);
  }

  async deleteChatSession(customerPhone: string): Promise<boolean> {
    return this.chatSessions.delete(customerPhone);
  }
}

export const storage = new MemStorage();
