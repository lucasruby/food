import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Edit } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import ChatContainer from '@/components/chat/ChatContainer';
import InputArea from '@/components/chat/InputArea';
import { Button } from '@/components/ui/button';
import PromptEditor from '@/components/modals/PromptEditor';
import { getWhatsAppStatus, getActivePrompt, updatePrompt, createPrompt } from '@/lib/api';
import { Message, Prompt } from '@shared/types';
import { generateResponse } from '@/lib/openai';
import { useToast } from '@/hooks/use-toast';

export default function ChatDemo() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isPromptEditorOpen, setIsPromptEditorOpen] = useState(false);
  const [activePrompt, setActivePrompt] = useState<Prompt | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isProcessingMessage, setIsProcessingMessage] = useState(false);
  const { toast } = useToast();

  // Get WhatsApp status
  const { data: whatsappStatusData } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                          whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Get active prompt
  const { data: promptData, isLoading: isLoadingPrompt, refetch: refetchPrompt } = useQuery({
    queryKey: ['/api/businesses/1/prompts/active'],
  });

  useEffect(() => {
    if (promptData) {
      setActivePrompt(promptData);
      
      // Initialize messages with system prompt and welcome message
      if (messages.length === 0) {
        const systemPrompt = promptData.content
          .replace("{{ storeName }}", "Pizzaria Catalana")
          .replace("{{ orderCode }}", "ORD-123456");
        
        setMessages([
          { 
            role: "system", 
            content: systemPrompt 
          },
          { 
            role: "assistant", 
            content: "Olá! Bem-vindo à Pizzaria Catalana 🍕 Como posso ajudar você hoje?",
            timestamp: new Date()
          }
        ]);
      }
    }
  }, [promptData]);

  // Save prompt mutation
  const savePromptMutation = useMutation({
    mutationFn: async (promptData: Partial<Prompt>) => {
      if (activePrompt && activePrompt.id) {
        return await updatePrompt(parseInt(activePrompt.id), promptData);
      } else {
        return await createPrompt({
          ...promptData,
          businessId: 1
        } as any);
      }
    },
    onSuccess: () => {
      refetchPrompt();
    }
  });

  const handleSendMessage = async (message: string) => {
    // Add user message to chat
    const userMessage: Message = {
      role: 'user',
      content: message,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsProcessingMessage(true);
    
    try {
      // Generate response using OpenAI
      const response = await generateResponse({
        messages: [...messages, userMessage]
      });
      
      if (!response) {
        throw new Error('Resposta vazia do servidor');
      }

      // Add assistant response to chat
      const assistantMessage: Message = {
        role: 'assistant',
        content: response,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
      toast({
        title: 'Erro',
        description: 'Houve um erro ao gerar uma resposta. Tente novamente.',
        variant: 'destructive'
      });
    } finally {
      setIsProcessingMessage(false);
    }
  };

  const handleEditTemplate = () => {
    setIsPromptEditorOpen(true);
  };

  const handleSavePrompt = async (promptData: Partial<Prompt>) => {
    await savePromptMutation.mutateAsync(promptData);
  };

  // Filter out system messages for display
  const displayMessages = messages.filter(msg => msg.role !== 'system');

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow flex flex-col">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <div className="flex items-center">
              <button 
                className="md:hidden mr-4 text-gray-500"
                onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
              <h2 className="font-['Roboto_Condensed'] font-bold text-lg">Visualização do Chat</h2>
            </div>
            <div>
              <Button 
                className="bg-[#FF6B00] text-white hover:bg-[#D95800]"
                onClick={handleEditTemplate}
              >
                <Edit className="h-4 w-4 mr-2" />
                Editar Template
              </Button>
            </div>
          </div>
          
          <ChatContainer messages={displayMessages} />
          
          <InputArea 
            onSendMessage={handleSendMessage} 
            disabled={isProcessingMessage || isLoadingPrompt}
            placeholder={isProcessingMessage ? "Bot está digitando..." : "Digite uma mensagem para testar o bot..."}
          />
        </div>
      </div>
      
      {isPromptEditorOpen && (
        <PromptEditor
          isOpen={isPromptEditorOpen}
          onClose={() => setIsPromptEditorOpen(false)}
          prompt={activePrompt || undefined}
          businessName="Pizzaria Catalana"
          onSave={handleSavePrompt}
        />
      )}
    </div>
  );
}
