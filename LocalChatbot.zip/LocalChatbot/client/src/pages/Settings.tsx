import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Save, Phone, Globe, Image, Mail, Key, RefreshCw } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getBusiness, updateBusiness, getWhatsAppStatus, restartWhatsApp } from '@/lib/api';

export default function Settings() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Get WhatsApp status
  const { data: whatsappStatusData, refetch: refetchWhatsAppStatus } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                          whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Get business data
  const { data: business, isLoading } = useQuery({
    queryKey: ['/api/businesses/1'],
    queryFn: () => getBusiness(1),
  });

  // Form state
  const [businessForm, setBusinessForm] = useState({
    name: '',
    type: '',
    address: '',
    phone: '',
    logo: ''
  });

  // Update form when business data is loaded
  useState(() => {
    if (business) {
      setBusinessForm({
        name: business.name || '',
        type: business.type || '',
        address: business.address || '',
        phone: business.phone || '',
        logo: business.logo || ''
      });
    }
  });

  // Update business mutation
  const updateBusinessMutation = useMutation({
    mutationFn: (data: any) => updateBusiness(1, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1'] });
      toast({
        title: 'Configurações salvas',
        description: 'As configurações do negócio foram atualizadas com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao salvar as configurações.',
        variant: 'destructive'
      });
    }
  });

  // Restart WhatsApp mutation
  const restartWhatsAppMutation = useMutation({
    mutationFn: restartWhatsApp,
    onSuccess: () => {
      refetchWhatsAppStatus();
      toast({
        title: 'WhatsApp reiniciado',
        description: 'O serviço WhatsApp foi reiniciado com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao reiniciar o WhatsApp.',
        variant: 'destructive'
      });
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setBusinessForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSaveBusinessSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateBusinessMutation.mutate(businessForm);
  };

  const handleRestartWhatsApp = () => {
    restartWhatsAppMutation.mutate();
  };

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow overflow-y-auto p-6">
          <h1 className="text-2xl font-bold mb-6">Configurações</h1>
          
          <Tabs defaultValue="business" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="business">Negócio</TabsTrigger>
              <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
              <TabsTrigger value="openai">OpenAI</TabsTrigger>
              <TabsTrigger value="bot">Bot</TabsTrigger>
            </TabsList>
            
            <TabsContent value="business">
              {isLoading ? (
                <div className="flex justify-center p-8">
                  <p>Carregando configurações...</p>
                </div>
              ) : (
                <form onSubmit={handleSaveBusinessSettings}>
                  <Card className="mb-6">
                    <CardHeader>
                      <CardTitle>Informações do Negócio</CardTitle>
                      <CardDescription>
                        Configure as informações básicas do seu negócio.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="name">Nome do Negócio</Label>
                          <Input
                            id="name"
                            name="name"
                            value={businessForm.name}
                            onChange={handleInputChange}
                            placeholder="Ex: Pizzaria Catalana"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="type">Tipo de Negócio</Label>
                          <Input
                            id="type"
                            name="type"
                            value={businessForm.type}
                            onChange={handleInputChange}
                            placeholder="Ex: Pizzaria, Restaurante, etc."
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="logo">URL do Logo</Label>
                        <div className="flex gap-2">
                          <Input
                            id="logo"
                            name="logo"
                            value={businessForm.logo}
                            onChange={handleInputChange}
                            placeholder="https://exemplo.com/logo.png"
                          />
                          <Button type="button" variant="outline" className="flex-shrink-0">
                            <Image className="h-4 w-4 mr-2" />
                            Upload
                          </Button>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="address">Endereço</Label>
                        <Textarea
                          id="address"
                          name="address"
                          value={businessForm.address}
                          onChange={handleInputChange}
                          placeholder="Endereço completo"
                          rows={3}
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="phone">Telefone</Label>
                        <Input
                          id="phone"
                          name="phone"
                          value={businessForm.phone}
                          onChange={handleInputChange}
                          placeholder="+5512999999999"
                        />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="mb-6">
                    <CardHeader>
                      <CardTitle>Configurações de Funcionamento</CardTitle>
                      <CardDescription>
                        Configure os horários de funcionamento e outras informações.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="openingHours">Horário de Abertura</Label>
                          <Input
                            id="openingHours"
                            type="time"
                            defaultValue="18:00"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="closingHours">Horário de Fechamento</Label>
                          <Input
                            id="closingHours"
                            type="time"
                            defaultValue="23:00"
                          />
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label>Dias de Funcionamento</Label>
                        <div className="grid grid-cols-4 md:grid-cols-7 gap-2">
                          {['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'].map((day) => (
                            <div key={day} className="flex items-center space-x-2">
                              <Switch id={`day-${day}`} defaultChecked={day !== 'Segunda'} />
                              <Label htmlFor={`day-${day}`}>{day.slice(0, 3)}</Label>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="deliveryRadius">Raio de Entrega (km)</Label>
                        <Input
                          id="deliveryRadius"
                          type="number"
                          defaultValue="5"
                          min="0"
                          step="0.5"
                        />
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="deliveryFee">Taxa de Entrega (R$)</Label>
                        <Input
                          id="deliveryFee"
                          type="number"
                          defaultValue="10.00"
                          min="0"
                          step="0.50"
                        />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      className="bg-[#FF6B00] hover:bg-[#D95800]"
                      disabled={updateBusinessMutation.isPending}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {updateBusinessMutation.isPending ? 'Salvando...' : 'Salvar Configurações'}
                    </Button>
                  </div>
                </form>
              )}
            </TabsContent>
            
            <TabsContent value="whatsapp">
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Configurações do WhatsApp</CardTitle>
                  <CardDescription>
                    Configure a integração com o WhatsApp.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gray-100 p-4 rounded-md">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className={`w-3 h-3 rounded-full mr-2 ${
                          whatsappStatus === 'online' ? 'bg-green-500' : 
                          whatsappStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
                        }`}></div>
                        <span className="font-medium">
                          Status: {whatsappStatus === 'online' ? 'Conectado' : 
                                   whatsappStatus === 'connecting' ? 'Conectando' : 'Desconectado'}
                        </span>
                      </div>
                      <Button 
                        variant="outline" 
                        onClick={handleRestartWhatsApp}
                        disabled={restartWhatsAppMutation.isPending}
                      >
                        <RefreshCw className="h-4 w-4 mr-2" />
                        {restartWhatsAppMutation.isPending ? 'Reiniciando...' : 'Reiniciar'}
                      </Button>
                    </div>
                    
                    {whatsappStatus === 'connecting' && whatsappStatusData?.qrCode && (
                      <div className="mt-4 flex flex-col items-center">
                        <p className="text-sm text-gray-500 mb-2">
                          Escaneie o QR Code abaixo com seu WhatsApp para conectar
                        </p>
                        <div className="bg-white p-4 rounded-md">
                          <img 
                            src={`data:image/png;base64,${whatsappStatusData.qrCode}`} 
                            alt="WhatsApp QR Code" 
                            className="w-64 h-64"
                          />
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="whatsappPhone">Número de Telefone do WhatsApp</Label>
                    <div className="flex items-center space-x-2">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <Input
                        id="whatsappPhone"
                        placeholder="+5512999999999"
                        defaultValue={business?.phone || ""}
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Mensagem de Boas-vindas</Label>
                    <Textarea
                      placeholder="Mensagem de boas-vindas para novos clientes"
                      defaultValue="Olá! Bem-vindo à Pizzaria Catalana 🍕 Como posso ajudar você hoje?"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Mensagem de Ausência</Label>
                    <Textarea
                      placeholder="Mensagem para quando o bot estiver desligado"
                      defaultValue="Olá! Estamos fora do horário de atendimento no momento. Nosso horário de funcionamento é de 18h às 23h. Retornaremos assim que possível!"
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Switch id="autoReply" defaultChecked />
                      <Label htmlFor="autoReply">Resposta Automática</Label>
                    </div>
                    <p className="text-sm text-gray-500">
                      Habilitar resposta automática para mensagens recebidas fora do horário de funcionamento
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="openai">
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Configurações da OpenAI</CardTitle>
                  <CardDescription>
                    Configure os parâmetros da integração com a OpenAI.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="apiKey">API Key</Label>
                    <div className="flex items-center space-x-2">
                      <Key className="h-4 w-4 text-gray-500" />
                      <Input
                        id="apiKey"
                        type="password"
                        placeholder="sk-..."
                        defaultValue="sk-***********************************"
                      />
                    </div>
                    <p className="text-xs text-gray-500">
                      A chave de API pode ser obtida no <a href="https://platform.openai.com/api-keys" target="_blank" className="text-[#FF6B00] hover:underline">painel da OpenAI</a>
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="model">Modelo</Label>
                    <Select defaultValue="gpt-4o">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um modelo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gpt-4o">GPT-4o (Recomendado)</SelectItem>
                        <SelectItem value="gpt-4">GPT-4</SelectItem>
                        <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500">
                      Modelos mais avançados oferecem melhores resultados, mas podem ser mais caros
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="temperature">Temperatura</Label>
                    <Input
                      id="temperature"
                      type="range"
                      min="0"
                      max="1"
                      step="0.1"
                      defaultValue="0.7"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>Consistente (0.0)</span>
                      <span>0.7</span>
                      <span>Criativo (1.0)</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="maxTokens">Máximo de Tokens</Label>
                    <Input
                      id="maxTokens"
                      type="number"
                      min="100"
                      max="4000"
                      step="100"
                      defaultValue="1000"
                    />
                    <p className="text-xs text-gray-500">
                      Limite de tokens para cada resposta (1 token ≈ 4 caracteres)
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Switch id="saveChat" defaultChecked />
                      <Label htmlFor="saveChat">Salvar Histórico de Conversa</Label>
                    </div>
                    <p className="text-sm text-gray-500">
                      Armazenar histórico de conversa para melhorar a experiência do usuário
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex justify-end">
                <Button className="bg-[#FF6B00] hover:bg-[#D95800]">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="bot">
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Configurações do Bot</CardTitle>
                  <CardDescription>
                    Configure os parâmetros de comportamento do bot.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Status do Bot</Label>
                    <div className="flex items-center space-x-2">
                      <Switch id="botStatus" defaultChecked />
                      <Label htmlFor="botStatus" className="font-medium">
                        Bot Ativo
                      </Label>
                    </div>
                    <p className="text-sm text-gray-500">
                      Quando desativado, o bot não responderá às mensagens
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Horário de Funcionamento do Bot</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="botStartTime" className="text-sm">Início</Label>
                        <Input
                          id="botStartTime"
                          type="time"
                          defaultValue="10:00"
                        />
                      </div>
                      <div>
                        <Label htmlFor="botEndTime" className="text-sm">Fim</Label>
                        <Input
                          id="botEndTime"
                          type="time"
                          defaultValue="23:00"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Comportamento</Label>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Switch id="autoOrderConfirmation" defaultChecked />
                        <Label htmlFor="autoOrderConfirmation">Confirmação Automática de Pedidos</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="promotionSuggestions" defaultChecked />
                        <Label htmlFor="promotionSuggestions">Sugestões de Promoções</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="customizationOptions" defaultChecked />
                        <Label htmlFor="customizationOptions">Opções de Personalização</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="upsellSuggestions" defaultChecked />
                        <Label htmlFor="upsellSuggestions">Sugestões de Adicionais</Label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="orderTimeEstimate">Tempo Estimado de Entrega (minutos)</Label>
                    <Input
                      id="orderTimeEstimate"
                      type="number"
                      min="15"
                      max="120"
                      step="5"
                      defaultValue="45"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Notificações</Label>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Switch id="notifyNewOrders" defaultChecked />
                        <Label htmlFor="notifyNewOrders">Notificar Novos Pedidos por Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="notifyCancelledOrders" defaultChecked />
                        <Label htmlFor="notifyCancelledOrders">Notificar Pedidos Cancelados</Label>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="notificationEmail">Email para Notificações</Label>
                    <div className="flex items-center space-x-2">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <Input
                        id="notificationEmail"
                        type="email"
                        placeholder="exemplo@email.com"
                        defaultValue=""
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex justify-end">
                <Button className="bg-[#FF6B00] hover:bg-[#D95800]">
                  <Save className="h-4 w-4 mr-2" />
                  Salvar Configurações
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
