import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Search, Plus, Download, Filter, Phone, Map, ShoppingBag } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';
import { getCustomersByBusiness, getWhatsAppStatus } from '@/lib/api';

export default function Customers() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  
  // Get WhatsApp status
  const { data: whatsappStatusData } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                          whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Get customers
  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['/api/businesses/1/customers'],
    queryFn: () => getCustomersByBusiness(1),
  });

  // Filter customers by search term
  const filteredCustomers = customers.filter((customer: any) => 
    customer.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    customer.phone.includes(searchTerm)
  );

  // Sort customers
  const sortedCustomers = [...filteredCustomers].sort((a: any, b: any) => {
    if (sortBy === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    } else if (sortBy === 'oldest') {
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    } else if (sortBy === 'orders') {
      return b.orderCount - a.orderCount;
    } else if (sortBy === 'name') {
      return a.name.localeCompare(b.name);
    }
    return 0;
  });

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow overflow-y-auto p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <h1 className="text-2xl font-bold">Clientes</h1>
            
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Buscar cliente..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 w-full md:w-[300px]"
                />
              </div>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full md:w-[180px]">
                  <SelectValue placeholder="Ordenar por" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Mais Recentes</SelectItem>
                  <SelectItem value="oldest">Mais Antigos</SelectItem>
                  <SelectItem value="orders">Mais Pedidos</SelectItem>
                  <SelectItem value="name">Nome</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" className="flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                Filtros
              </Button>
              
              <Button variant="outline" className="flex items-center">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
              
              <Button className="bg-[#FF6B00] hover:bg-[#D95800] flex items-center">
                <Plus className="h-4 w-4 mr-2" />
                Adicionar Cliente
              </Button>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center p-8">
              <p>Carregando clientes...</p>
            </div>
          ) : (
            <>
              {sortedCustomers.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                  {sortedCustomers.map((customer: any) => (
                    <CustomerCard 
                      key={customer.id}
                      name={customer.name}
                      phone={customer.phone}
                      address={customer.address || 'Sem endereço cadastrado'}
                      orderCount={customer.orderCount || 0}
                      createdAt={customer.createdAt}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 p-8 rounded-md text-center">
                  <ShoppingBag className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">Nenhum cliente encontrado</h3>
                  <p className="text-gray-500 mb-4">
                    {searchTerm ? 
                      'Nenhum cliente corresponde aos critérios de busca.' : 
                      'Você ainda não possui clientes cadastrados.'}
                  </p>
                  {!searchTerm && (
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Adicionar Cliente
                    </Button>
                  )}
                </div>
              )}
              
              {sortedCustomers.length > 0 && (
                <Pagination className="mt-6">
                  <PaginationContent>
                    <PaginationItem>
                      <PaginationPrevious href="#" />
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#" isActive>1</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#">2</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationLink href="#">3</PaginationLink>
                    </PaginationItem>
                    <PaginationItem>
                      <PaginationNext href="#" />
                    </PaginationItem>
                  </PaginationContent>
                </Pagination>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

interface CustomerCardProps {
  name: string;
  phone: string;
  address: string;
  orderCount: number;
  createdAt: string;
}

function CustomerCard({ name, phone, address, orderCount, createdAt }: CustomerCardProps) {
  // Format createdAt date
  const formattedDate = new Date(createdAt).toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric'
  });

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className="w-12 h-12 bg-[#FF6B00] rounded-full flex items-center justify-center text-white font-bold text-lg">
            {name.charAt(0)}
          </div>
          <div className="ml-3">
            <h3 className="font-bold text-lg">{name}</h3>
            <p className="text-sm text-gray-500">Cliente desde {formattedDate}</p>
          </div>
        </div>
        
        <div className="space-y-2 mb-4">
          <div className="flex items-center">
            <Phone className="h-4 w-4 text-gray-500 mr-2" />
            <p className="text-sm">{phone}</p>
          </div>
          <div className="flex items-start">
            <Map className="h-4 w-4 text-gray-500 mr-2 mt-1" />
            <p className="text-sm flex-1">{address}</p>
          </div>
          <div className="flex items-center">
            <ShoppingBag className="h-4 w-4 text-gray-500 mr-2" />
            <p className="text-sm">{orderCount} pedidos realizados</p>
          </div>
        </div>
        
        <div className="flex justify-between mt-4">
          <Button variant="outline" size="sm" className="flex items-center">
            <Phone className="h-4 w-4 mr-1" />
            WhatsApp
          </Button>
          <Button variant="outline" size="sm" className="flex items-center">
            Ver Pedidos
          </Button>
          <Button variant="outline" size="sm" className="flex items-center">
            Editar
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
