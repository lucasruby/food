import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { Clock, ShoppingBag, Utensils, DollarSign } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { getWhatsAppStatus } from '@/lib/api';

export default function Dashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const { data: whatsappStatusData, isLoading: isLoadingStatus } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                          whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Sample data for the charts
  const orderData = [
    { name: 'Dom', orders: 15 },
    { name: 'Seg', orders: 8 },
    { name: 'Ter', orders: 10 },
    { name: 'Qua', orders: 12 },
    { name: 'Qui', orders: 11 },
    { name: 'Sex', orders: 18 },
    { name: 'Sáb', orders: 20 },
  ];

  const revenueData = [
    { name: 'Dom', revenue: 950 },
    { name: 'Seg', revenue: 520 },
    { name: 'Ter', revenue: 650 },
    { name: 'Qua', revenue: 780 },
    { name: 'Qui', revenue: 720 },
    { name: 'Sex', revenue: 1150 },
    { name: 'Sáb', revenue: 1280 },
  ];

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} 
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow overflow-y-auto p-6">
          <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard 
              title="Pedidos Hoje" 
              value="12" 
              change="+20%" 
              icon={<ShoppingBag className="h-8 w-8 text-blue-500" />}
            />
            
            <StatCard 
              title="Receita Hoje" 
              value="R$780,50" 
              change="+15%" 
              icon={<DollarSign className="h-8 w-8 text-green-500" />}
            />
            
            <StatCard 
              title="Tempo Médio" 
              value="32 min" 
              change="-5%" 
              positive={false}
              icon={<Clock className="h-8 w-8 text-amber-500" />}
            />
            
            <StatCard 
              title="Pedidos Pendentes" 
              value="3" 
              icon={<Utensils className="h-8 w-8 text-red-500" />}
            />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <Card>
              <CardHeader>
                <CardTitle>Pedidos da Semana</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={orderData}
                      margin={{
                        top: 5,
                        right: 10,
                        left: 0,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="orders" fill="#FF6B00" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Receita da Semana</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={revenueData}
                      margin={{
                        top: 5,
                        right: 10,
                        left: 0,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value: number) => [`R$${value.toFixed(2)}`, 'Receita']}
                      />
                      <Bar dataKey="revenue" fill="#FF3A3A" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Últimos Pedidos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-2">Pedido</th>
                      <th className="text-left py-3 px-2">Cliente</th>
                      <th className="text-left py-3 px-2">Status</th>
                      <th className="text-left py-3 px-2">Forma de Pag.</th>
                      <th className="text-right py-3 px-2">Valor</th>
                    </tr>
                  </thead>
                  <tbody>
                    <OrderRow 
                      id="1234"
                      customer="João Silva" 
                      status="completed" 
                      payment="Cartão de Crédito" 
                      amount={84.99} 
                    />
                    <OrderRow 
                      id="1233"
                      customer="Maria Oliveira" 
                      status="delivering" 
                      payment="PIX" 
                      amount={64.99} 
                    />
                    <OrderRow 
                      id="1232"
                      customer="Carlos Santos" 
                      status="preparing" 
                      payment="Dinheiro" 
                      amount={74.99} 
                    />
                    <OrderRow 
                      id="1231"
                      customer="Ana Pereira" 
                      status="pending" 
                      payment="Cartão de Débito" 
                      amount={54.99} 
                    />
                    <OrderRow 
                      id="1230"
                      customer="Pedro Costa" 
                      status="cancelled" 
                      payment="PIX" 
                      amount={44.99} 
                    />
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: string;
  change?: string;
  positive?: boolean;
  icon?: React.ReactNode;
}

function StatCard({ title, value, change, positive = true, icon }: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm font-medium text-gray-500">{title}</p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
            {change && (
              <p className={`text-xs mt-1 ${positive ? 'text-green-500' : 'text-red-500'}`}>
                {change} desde ontem
              </p>
            )}
          </div>
          {icon}
        </div>
      </CardContent>
    </Card>
  );
}

interface OrderRowProps {
  id: string;
  customer: string;
  status: 'pending' | 'preparing' | 'delivering' | 'completed' | 'cancelled';
  payment: string;
  amount: number;
}

function OrderRow({ id, customer, status, payment, amount }: OrderRowProps) {
  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-800',
    preparing: 'bg-blue-100 text-blue-800',
    delivering: 'bg-purple-100 text-purple-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };
  
  const statusText = {
    pending: 'Pendente',
    preparing: 'Preparando',
    delivering: 'Entregando',
    completed: 'Concluído',
    cancelled: 'Cancelado',
  };

  return (
    <tr className="border-b hover:bg-gray-50">
      <td className="py-3 px-2 font-medium">#{id}</td>
      <td className="py-3 px-2">{customer}</td>
      <td className="py-3 px-2">
        <span className={`px-2 py-1 rounded-full text-xs ${statusColors[status]}`}>
          {statusText[status]}
        </span>
      </td>
      <td className="py-3 px-2">{payment}</td>
      <td className="py-3 px-2 text-right font-medium">R${amount.toFixed(2)}</td>
    </tr>
  );
}
