import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Tag } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import PizzaCard from '@/components/ui/pizza-card';
import { Button } from '@/components/ui/button';
import PromotionEditor from '@/components/modals/PromotionEditor';
import { useToast } from '@/hooks/use-toast';
import { 
  getPromotionsByBusiness, 
  createPromotion,
  updatePromotion,
  deletePromotion,
  getPizzasByBusiness,
  getMenuItemsByBusiness,
  getWhatsAppStatus
} from '@/lib/api';
import { Promotion, Pizza, MenuItem } from '@shared/types';

export default function Promotions() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isPromotionEditorOpen, setIsPromotionEditorOpen] = useState(false);
  const [currentPromotion, setCurrentPromotion] = useState<Promotion | null>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Get WhatsApp status
  const { data: whatsappStatusData } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                          whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Get promotions
  const { data: promotions = [], isLoading: isLoadingPromotions } = useQuery({
    queryKey: ['/api/businesses/1/promotions'],
    queryFn: () => getPromotionsByBusiness(1),
  });

  // Get pizzas for the selector
  const { data: pizzas = [] } = useQuery({
    queryKey: ['/api/businesses/1/pizzas'],
    queryFn: () => getPizzasByBusiness(1),
  });

  // Get menu items for the selector
  const { data: menuItems = [] } = useQuery({
    queryKey: ['/api/businesses/1/menuitems'],
    queryFn: () => getMenuItemsByBusiness(1),
  });

  // Format options for the promotion editor
  const pizzaOptions = pizzas.map((pizza: Pizza) => ({
    id: pizza.id,
    name: pizza.name,
    size: pizza.size
  }));

  const drinkOptions = menuItems
    .filter((item: MenuItem) => item.category === 'Bebidas')
    .map((item: MenuItem) => ({
      id: item.id,
      name: item.name
    }));

  // Create promotion mutation
  const createPromotionMutation = useMutation({
    mutationFn: (promotion: Omit<Promotion, 'id'>) => createPromotion(promotion),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/promotions'] });
      toast({
        title: 'Promoção Adicionada',
        description: 'A promoção foi adicionada com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao adicionar a promoção.',
        variant: 'destructive'
      });
    }
  });

  // Update promotion mutation
  const updatePromotionMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: Partial<Promotion> }) => updatePromotion(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/promotions'] });
      toast({
        title: 'Promoção Atualizada',
        description: 'A promoção foi atualizada com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao atualizar a promoção.',
        variant: 'destructive'
      });
    }
  });

  // Delete promotion mutation
  const deletePromotionMutation = useMutation({
    mutationFn: (id: number) => deletePromotion(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/promotions'] });
      toast({
        title: 'Promoção Removida',
        description: 'A promoção foi removida com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao remover a promoção.',
        variant: 'destructive'
      });
    }
  });

  const handleAddPromotion = () => {
    setCurrentPromotion(null);
    setIsPromotionEditorOpen(true);
  };

  const handleEditPromotion = (promotion: Promotion) => {
    setCurrentPromotion(promotion);
    setIsPromotionEditorOpen(true);
  };

  const handleDeletePromotion = (id: string) => {
    deletePromotionMutation.mutate(parseInt(id));
  };

  const handleSavePromotion = async (promotion: Partial<Promotion>) => {
    if (currentPromotion) {
      await updatePromotionMutation.mutateAsync({ 
        id: parseInt(currentPromotion.id), 
        data: promotion 
      });
    } else {
      await createPromotionMutation.mutateAsync(promotion as Omit<Promotion, 'id'>);
    }
    
    setIsPromotionEditorOpen(false);
  };

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Promoções</h1>
            <Button
              onClick={handleAddPromotion}
              className="bg-[#FF6B00] hover:bg-[#D95800] flex items-center"
            >
              <Plus className="h-4 w-4 mr-2" />
              <Tag className="h-4 w-4 mr-2" />
              Adicionar Promoção
            </Button>
          </div>
          
          {isLoadingPromotions ? (
            <div className="flex justify-center p-8">
              <p>Carregando promoções...</p>
            </div>
          ) : (
            <>
              {promotions.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {promotions.map((promotion: Promotion) => (
                    <PizzaCard
                      key={promotion.id}
                      item={promotion}
                      type="promotion"
                      onEdit={() => handleEditPromotion(promotion)}
                      onDelete={() => handleDeletePromotion(promotion.id)}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-gray-50 p-8 rounded-md text-center">
                  <Tag className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">Nenhuma promoção cadastrada</h3>
                  <p className="text-gray-500 mb-4">Adicione promoções para atrair mais clientes e aumentar as vendas.</p>
                  <Button onClick={handleAddPromotion}>
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar Promoção
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
      
      {isPromotionEditorOpen && (
        <PromotionEditor
          isOpen={isPromotionEditorOpen}
          onClose={() => setIsPromotionEditorOpen(false)}
          promotion={currentPromotion || undefined}
          businessId={1}
          onSave={handleSavePromotion}
          pizzaOptions={pizzaOptions}
          drinkOptions={drinkOptions}
        />
      )}
    </div>
  );
}
