import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Pizza as PizzaIcon, Coffee } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import PizzaCard from '@/components/ui/pizza-card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import MenuEditor from '@/components/modals/MenuEditor';
import { useToast } from '@/hooks/use-toast';
import { 
  getPizzasByBusiness, 
  getMenuItemsByBusiness,
  createPizza,
  updatePizza,
  deletePizza,
  createMenuItem,
  updateMenuItem,
  deleteMenuItem,
  getWhatsAppStatus
} from '@/lib/api';
import { Pizza, MenuItem } from '@shared/schema';

export default function Menu() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMenuEditorOpen, setIsMenuEditorOpen] = useState(false);
  const [currentItem, setCurrentItem] = useState<Pizza | MenuItem | null>(null);
  const [editorType, setEditorType] = useState<'pizza' | 'menuItem'>('pizza');
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Get WhatsApp status
  const { data: whatsappStatusData } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                         whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Get pizzas
  const { data: pizzas = [], isLoading: isLoadingPizzas } = useQuery({
    queryKey: ['/api/businesses/1/pizzas'],
    queryFn: () => getPizzasByBusiness(1),
  });

  // Get menu items
  const { data: menuItems = [], isLoading: isLoadingMenuItems } = useQuery({
    queryKey: ['/api/businesses/1/menuitems'],
    queryFn: () => getMenuItemsByBusiness(1),
  });

  // Create pizza mutation
  const createPizzaMutation = useMutation({
    mutationFn: (pizza: Omit<Pizza, 'id'>) => createPizza(pizza),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/pizzas'] });
      toast({
        title: 'Pizza Adicionada',
        description: 'A pizza foi adicionada com sucesso ao cardápio.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao adicionar a pizza.',
        variant: 'destructive'
      });
    }
  });

  // Update pizza mutation
  const updatePizzaMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: Partial<Pizza> }) => updatePizza(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/pizzas'] });
      toast({
        title: 'Pizza Atualizada',
        description: 'A pizza foi atualizada com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao atualizar a pizza.',
        variant: 'destructive'
      });
    }
  });

  // Delete pizza mutation
  const deletePizzaMutation = useMutation({
    mutationFn: (id: number) => deletePizza(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/pizzas'] });
      toast({
        title: 'Pizza Removida',
        description: 'A pizza foi removida com sucesso do cardápio.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao remover a pizza.',
        variant: 'destructive'
      });
    }
  });

  // Create menu item mutation
  const createMenuItemMutation = useMutation({
    mutationFn: (menuItem: Omit<MenuItem, 'id'>) => createMenuItem(menuItem),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/menuitems'] });
      toast({
        title: 'Item Adicionado',
        description: 'O item foi adicionado com sucesso ao cardápio.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao adicionar o item.',
        variant: 'destructive'
      });
    }
  });

  // Update menu item mutation
  const updateMenuItemMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: Partial<MenuItem> }) => updateMenuItem(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/menuitems'] });
      toast({
        title: 'Item Atualizado',
        description: 'O item foi atualizado com sucesso.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao atualizar o item.',
        variant: 'destructive'
      });
    }
  });

  // Delete menu item mutation
  const deleteMenuItemMutation = useMutation({
    mutationFn: (id: number) => deleteMenuItem(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/businesses/1/menuitems'] });
      toast({
        title: 'Item Removido',
        description: 'O item foi removido com sucesso do cardápio.'
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao remover o item.',
        variant: 'destructive'
      });
    }
  });

  const handleAddItem = (type: 'pizza' | 'menuItem') => {
    setCurrentItem(null);
    setEditorType(type);
    setIsMenuEditorOpen(true);
  };

  const handleEditItem = (item: Pizza | MenuItem, type: 'pizza' | 'menuItem') => {
    setCurrentItem(item);
    setEditorType(type);
    setIsMenuEditorOpen(true);
  };

  const handleDeleteItem = (id: string, type: 'pizza' | 'menuItem') => {
    if (type === 'pizza') {
      deletePizzaMutation.mutate(parseInt(id));
    } else {
      deleteMenuItemMutation.mutate(parseInt(id));
    }
  };

  const handleSaveItem = async (item: Partial<Pizza | MenuItem>) => {
    if (editorType === 'pizza') {
      if (currentItem) {
        await updatePizzaMutation.mutateAsync({ 
          id: parseInt(currentItem.id), 
          data: item as Partial<Pizza> 
        });
      } else {
        await createPizzaMutation.mutateAsync(item as Omit<Pizza, 'id'>);
      }
    } else {
      if (currentItem) {
        await updateMenuItemMutation.mutateAsync({ 
          id: parseInt(currentItem.id), 
          data: item as Partial<MenuItem> 
        });
      } else {
        await createMenuItemMutation.mutateAsync(item as Omit<MenuItem, 'id'>);
      }
    }
    
    setIsMenuEditorOpen(false);
  };

  // Filter menu items by category
  const drinks = menuItems.filter(item => item.category === 'Bebidas');
  const desserts = menuItems.filter(item => item.category === 'Sobremesas');
  const others = menuItems.filter(item => item.category !== 'Bebidas' && item.category !== 'Sobremesas');

  // Filter pizzas by category
  const traditionalPizzas = pizzas.filter(pizza => pizza.category === 'Tradicional');
  const specialPizzas = pizzas.filter(pizza => pizza.category === 'Especial');
  const sweetPizzas = pizzas.filter(pizza => pizza.category === 'Doce');

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow overflow-y-auto p-6">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">Cardápio</h1>
            <div className="space-x-2">
              <Button
                variant="outline"
                onClick={() => handleAddItem('menuItem')}
                className="flex items-center"
              >
                <Plus className="h-4 w-4 mr-2" />
                <Coffee className="h-4 w-4 mr-2" />
                Adicionar Item
              </Button>
              <Button
                onClick={() => handleAddItem('pizza')}
                className="bg-[#FF6B00] hover:bg-[#D95800] flex items-center"
              >
                <Plus className="h-4 w-4 mr-2" />
                <PizzaIcon className="h-4 w-4 mr-2" />
                Adicionar Pizza
              </Button>
            </div>
          </div>
          
          <Tabs defaultValue="pizzas" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="pizzas">Pizzas</TabsTrigger>
              <TabsTrigger value="drinks">Bebidas</TabsTrigger>
              <TabsTrigger value="others">Outros Itens</TabsTrigger>
            </TabsList>
            
            <TabsContent value="pizzas">
              {isLoadingPizzas ? (
                <div className="flex justify-center p-8">
                  <p>Carregando pizzas...</p>
                </div>
              ) : (
                <>
                  {traditionalPizzas.length > 0 && (
                    <>
                      <h2 className="font-bold text-lg mb-3 mt-6">Pizzas Tradicionais</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                        {traditionalPizzas.map(pizza => (
                          <PizzaCard
                            key={pizza.id}
                            item={pizza}
                            type="pizza"
                            onEdit={(item) => handleEditItem(item, 'pizza')}
                            onDelete={(id) => handleDeleteItem(id, 'pizza')}
                          />
                        ))}
                      </div>
                    </>
                  )}
                  
                  {specialPizzas.length > 0 && (
                    <>
                      <h2 className="font-bold text-lg mb-3 mt-6">Pizzas Especiais</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                        {specialPizzas.map(pizza => (
                          <PizzaCard
                            key={pizza.id}
                            item={pizza}
                            type="pizza"
                            onEdit={(item) => handleEditItem(item, 'pizza')}
                            onDelete={(id) => handleDeleteItem(id, 'pizza')}
                          />
                        ))}
                      </div>
                    </>
                  )}
                  
                  {sweetPizzas.length > 0 && (
                    <>
                      <h2 className="font-bold text-lg mb-3 mt-6">Pizzas Doces</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                        {sweetPizzas.map(pizza => (
                          <PizzaCard
                            key={pizza.id}
                            item={pizza}
                            type="pizza"
                            onEdit={(item) => handleEditItem(item, 'pizza')}
                            onDelete={(id) => handleDeleteItem(id, 'pizza')}
                          />
                        ))}
                      </div>
                    </>
                  )}
                  
                  {pizzas.length === 0 && (
                    <div className="bg-gray-50 p-8 rounded-md text-center">
                      <PizzaIcon className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                      <h3 className="text-lg font-semibold mb-2">Nenhuma pizza cadastrada</h3>
                      <p className="text-gray-500 mb-4">Adicione pizzas ao cardápio para que apareçam aqui.</p>
                      <Button onClick={() => handleAddItem('pizza')}>
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Pizza
                      </Button>
                    </div>
                  )}
                </>
              )}
            </TabsContent>
            
            <TabsContent value="drinks">
              {isLoadingMenuItems ? (
                <div className="flex justify-center p-8">
                  <p>Carregando bebidas...</p>
                </div>
              ) : (
                <>
                  {drinks.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                      {drinks.map(drink => (
                        <PizzaCard
                          key={drink.id}
                          item={drink}
                          type="menuItem"
                          onEdit={(item) => handleEditItem(item, 'menuItem')}
                          onDelete={(id) => handleDeleteItem(id, 'menuItem')}
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="bg-gray-50 p-8 rounded-md text-center">
                      <Coffee className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                      <h3 className="text-lg font-semibold mb-2">Nenhuma bebida cadastrada</h3>
                      <p className="text-gray-500 mb-4">Adicione bebidas ao cardápio para que apareçam aqui.</p>
                      <Button variant="outline" onClick={() => handleAddItem('menuItem')}>
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Bebida
                      </Button>
                    </div>
                  )}
                </>
              )}
            </TabsContent>
            
            <TabsContent value="others">
              {isLoadingMenuItems ? (
                <div className="flex justify-center p-8">
                  <p>Carregando itens...</p>
                </div>
              ) : (
                <>
                  {desserts.length > 0 && (
                    <>
                      <h2 className="font-bold text-lg mb-3 mt-6">Sobremesas</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                        {desserts.map(item => (
                          <PizzaCard
                            key={item.id}
                            item={item}
                            type="menuItem"
                            onEdit={(item) => handleEditItem(item, 'menuItem')}
                            onDelete={(id) => handleDeleteItem(id, 'menuItem')}
                          />
                        ))}
                      </div>
                    </>
                  )}
                  
                  {others.length > 0 && (
                    <>
                      <h2 className="font-bold text-lg mb-3 mt-6">Outros Itens</h2>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                        {others.map(item => (
                          <PizzaCard
                            key={item.id}
                            item={item}
                            type="menuItem"
                            onEdit={(item) => handleEditItem(item, 'menuItem')}
                            onDelete={(id) => handleDeleteItem(id, 'menuItem')}
                          />
                        ))}
                      </div>
                    </>
                  )}
                  
                  {desserts.length === 0 && others.length === 0 && (
                    <div className="bg-gray-50 p-8 rounded-md text-center">
                      <Utensils className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                      <h3 className="text-lg font-semibold mb-2">Nenhum item adicional cadastrado</h3>
                      <p className="text-gray-500 mb-4">Adicione sobremesas e outros itens ao cardápio para que apareçam aqui.</p>
                      <Button variant="outline" onClick={() => handleAddItem('menuItem')}>
                        <Plus className="h-4 w-4 mr-2" />
                        Adicionar Item
                      </Button>
                    </div>
                  )}
                </>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {isMenuEditorOpen && (
        <MenuEditor
          isOpen={isMenuEditorOpen}
          onClose={() => setIsMenuEditorOpen(false)}
          item={currentItem || undefined}
          type={editorType}
          businessId={1}
          onSave={handleSaveItem}
        />
      )}
    </div>
  );
}

// Import missing component
function Utensils(props: any) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2" />
      <path d="M7 2v20" />
      <path d="M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7" />
    </svg>
  );
}
