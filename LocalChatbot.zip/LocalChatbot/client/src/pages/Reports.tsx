import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { Calendar, Download, Filter } from 'lucide-react';
import Header from '@/components/layout/Header';
import Sidebar from '@/components/layout/Sidebar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { getWhatsAppStatus } from '@/lib/api';

export default function Reports() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [dateRange, setDateRange] = useState('week');
  
  // Get WhatsApp status
  const { data: whatsappStatusData } = useQuery({
    queryKey: ['/api/whatsapp/status'],
  });

  const whatsappStatus = whatsappStatusData?.status === 'connected' ? 'online' : 
                          whatsappStatusData?.status === 'connecting' ? 'connecting' : 'offline';

  // Sample data for charts
  const salesData = [
    { name: 'Dom', sales: 12, revenue: 950 },
    { name: 'Seg', sales: 8, revenue: 520 },
    { name: 'Ter', sales: 10, revenue: 650 },
    { name: 'Qua', sales: 12, revenue: 780 },
    { name: 'Qui', sales: 11, revenue: 720 },
    { name: 'Sex', sales: 18, revenue: 1150 },
    { name: 'Sáb', sales: 20, revenue: 1280 },
  ];

  const productData = [
    { name: 'Catalana', value: 25 },
    { name: 'Bacon', value: 20 },
    { name: 'À Moda', value: 18 },
    { name: 'Bauru', value: 15 },
    { name: 'Goiana', value: 12 },
    { name: 'Outras', value: 10 },
  ];

  const COLORS = ['#FF6B00', '#FF9F40', '#FFB366', '#FFC78C', '#FFD9B3', '#FFECDA'];

  // Hourly sales data
  const hourlyData = [
    { hour: '18:00', orders: 4 },
    { hour: '19:00', orders: 10 },
    { hour: '20:00', orders: 15 },
    { hour: '21:00', orders: 12 },
    { hour: '22:00', orders: 8 },
    { hour: '23:00', orders: 6 },
  ];

  return (
    <div className="flex flex-col h-screen max-w-6xl mx-auto bg-white shadow-md">
      <Header 
        toggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        whatsappStatus={whatsappStatus}
      />
      
      <div className="flex flex-grow overflow-hidden">
        <Sidebar isOpen={isSidebarOpen} />
        
        <div className="flex-grow overflow-y-auto p-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <h1 className="text-2xl font-bold">Relatórios</h1>
            
            <div className="flex flex-col md:flex-row gap-2 w-full md:w-auto">
              <div className="flex-grow md:flex-grow-0">
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-full md:w-[180px]">
                    <Calendar className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="today">Hoje</SelectItem>
                    <SelectItem value="yesterday">Ontem</SelectItem>
                    <SelectItem value="week">Esta Semana</SelectItem>
                    <SelectItem value="month">Este Mês</SelectItem>
                    <SelectItem value="custom">Personalizado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button variant="outline" className="flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                Filtros
              </Button>
              
              <Button variant="outline" className="flex items-center">
                <Download className="h-4 w-4 mr-2" />
                Exportar
              </Button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-gray-500">Pedidos</span>
                  <span className="text-3xl font-bold mt-1">91</span>
                  <span className="text-xs text-green-500 mt-1">+8% desde semana passada</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-gray-500">Receita</span>
                  <span className="text-3xl font-bold mt-1">R$6.050,00</span>
                  <span className="text-xs text-green-500 mt-1">+12% desde semana passada</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-gray-500">Ticket Médio</span>
                  <span className="text-3xl font-bold mt-1">R$66,48</span>
                  <span className="text-xs text-green-500 mt-1">+3% desde semana passada</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-gray-500">Clientes Novos</span>
                  <span className="text-3xl font-bold mt-1">18</span>
                  <span className="text-xs text-green-500 mt-1">+5% desde semana passada</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="products">Produtos</TabsTrigger>
              <TabsTrigger value="customers">Clientes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Vendas e Receita</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={salesData}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis yAxisId="left" orientation="left" />
                          <YAxis yAxisId="right" orientation="right" />
                          <Tooltip />
                          <Legend />
                          <Bar yAxisId="left" dataKey="sales" name="Pedidos" fill="#FF6B00" />
                          <Bar yAxisId="right" dataKey="revenue" name="Receita (R$)" fill="#FF3A3A" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Pedidos por Hora</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={hourlyData}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="hour" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Line type="monotone" dataKey="orders" name="Pedidos" stroke="#FF6B00" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Últimos Pedidos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-2">Pedido</th>
                          <th className="text-left py-3 px-2">Data</th>
                          <th className="text-left py-3 px-2">Cliente</th>
                          <th className="text-left py-3 px-2">Status</th>
                          <th className="text-left py-3 px-2">Itens</th>
                          <th className="text-right py-3 px-2">Valor</th>
                        </tr>
                      </thead>
                      <tbody>
                        <OrderRow 
                          id="1234"
                          date="Hoje, 20:45"
                          customer="João Silva" 
                          status="completed" 
                          items="COMBO MASTER"
                          amount={84.99} 
                        />
                        <OrderRow 
                          id="1233"
                          date="Hoje, 19:32"
                          customer="Maria Oliveira" 
                          status="delivering" 
                          items="COMBO PREMIUM"
                          amount={64.99} 
                        />
                        <OrderRow 
                          id="1232"
                          date="Hoje, 19:15"
                          customer="Carlos Santos" 
                          status="preparing" 
                          items="Pizza GG + Bebidas"
                          amount={74.99} 
                        />
                        <OrderRow 
                          id="1231"
                          date="Hoje, 18:50"
                          customer="Ana Pereira" 
                          status="completed" 
                          items="Pizza G + Bebidas"
                          amount={54.99} 
                        />
                        <OrderRow 
                          id="1230"
                          date="Hoje, 18:25"
                          customer="Pedro Costa" 
                          status="completed" 
                          items="COMBO ESFIHAS"
                          amount={44.99} 
                        />
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="products">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Pizzas Mais Vendidas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={productData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            {productData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip formatter={(value) => [`${value} pedidos`, 'Quantidade']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Top Produtos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-3 px-2">Produto</th>
                            <th className="text-center py-3 px-2">Qtd Vendida</th>
                            <th className="text-right py-3 px-2">Receita</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="border-b">
                            <td className="py-3 px-2 font-medium">Pizza Catalana</td>
                            <td className="py-3 px-2 text-center">25</td>
                            <td className="py-3 px-2 text-right">R$ 1.374,75</td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3 px-2 font-medium">Pizza Bacon</td>
                            <td className="py-3 px-2 text-center">20</td>
                            <td className="py-3 px-2 text-right">R$ 1.099,80</td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3 px-2 font-medium">Pizza À Moda</td>
                            <td className="py-3 px-2 text-center">18</td>
                            <td className="py-3 px-2 text-right">R$ 989,82</td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3 px-2 font-medium">Pizza Bauru</td>
                            <td className="py-3 px-2 text-center">15</td>
                            <td className="py-3 px-2 text-right">R$ 824,85</td>
                          </tr>
                          <tr className="border-b">
                            <td className="py-3 px-2 font-medium">Pizza Goiana</td>
                            <td className="py-3 px-2 text-center">12</td>
                            <td className="py-3 px-2 text-right">R$ 659,88</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Desempenho das Promoções</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={[
                          { name: 'COMBO MASTER', value: 32 },
                          { name: 'COMBO PREMIUM', value: 28 },
                          { name: 'COMBO ESFIHAS', value: 15 },
                          { name: 'Pizza GG', value: 10 },
                          { name: 'Pizza G', value: 6 },
                        ]}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                        layout="vertical"
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis type="number" />
                        <YAxis dataKey="name" type="category" />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="value" name="Vendas" fill="#FF3A3A" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="customers">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Novos Clientes vs. Recorrentes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Novos', value: 18 },
                              { name: 'Recorrentes', value: 73 },
                            ]}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          >
                            <Cell fill="#FF6B00" />
                            <Cell fill="#FFBB00" />
                          </Pie>
                          <Tooltip formatter={(value) => [`${value} clientes`, 'Quantidade']} />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Frequência de Compra</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={[
                            { name: '1ª vez', value: 18 },
                            { name: '2-3 vezes', value: 25 },
                            { name: '4-6 vezes', value: 22 },
                            { name: '7-10 vezes', value: 15 },
                            { name: '10+ vezes', value: 11 },
                          ]}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="value" name="Clientes" fill="#FF6B00" />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <Card>
                <CardHeader>
                  <CardTitle>Top Clientes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-2">Cliente</th>
                          <th className="text-left py-3 px-2">Telefone</th>
                          <th className="text-center py-3 px-2">Pedidos</th>
                          <th className="text-right py-3 px-2">Total Gasto</th>
                          <th className="text-right py-3 px-2">Ticket Médio</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="py-3 px-2 font-medium">João Silva</td>
                          <td className="py-3 px-2">(12) 99999-8888</td>
                          <td className="py-3 px-2 text-center">12</td>
                          <td className="py-3 px-2 text-right">R$ 950,88</td>
                          <td className="py-3 px-2 text-right">R$ 79,24</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3 px-2 font-medium">Maria Oliveira</td>
                          <td className="py-3 px-2">(12) 99888-7777</td>
                          <td className="py-3 px-2 text-center">10</td>
                          <td className="py-3 px-2 text-right">R$ 785,90</td>
                          <td className="py-3 px-2 text-right">R$ 78,59</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3 px-2 font-medium">Carlos Santos</td>
                          <td className="py-3 px-2">(12) 97777-6666</td>
                          <td className="py-3 px-2 text-center">8</td>
                          <td className="py-3 px-2 text-right">R$ 593,92</td>
                          <td className="py-3 px-2 text-right">R$ 74,24</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3 px-2 font-medium">Ana Pereira</td>
                          <td className="py-3 px-2">(12) 96666-5555</td>
                          <td className="py-3 px-2 text-center">7</td>
                          <td className="py-3 px-2 text-right">R$ 505,93</td>
                          <td className="py-3 px-2 text-right">R$ 72,28</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3 px-2 font-medium">Pedro Costa</td>
                          <td className="py-3 px-2">(12) 95555-4444</td>
                          <td className="py-3 px-2 text-center">6</td>
                          <td className="py-3 px-2 text-right">R$ 424,94</td>
                          <td className="py-3 px-2 text-right">R$ 70,82</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

interface OrderRowProps {
  id: string;
  date: string;
  customer: string;
  status: 'pending' | 'preparing' | 'delivering' | 'completed' | 'cancelled';
  items: string;
  amount: number;
}

function OrderRow({ id, date, customer, status, items, amount }: OrderRowProps) {
  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-800',
    preparing: 'bg-blue-100 text-blue-800',
    delivering: 'bg-purple-100 text-purple-800',
    completed: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };
  
  const statusText = {
    pending: 'Pendente',
    preparing: 'Preparando',
    delivering: 'Entregando',
    completed: 'Concluído',
    cancelled: 'Cancelado',
  };

  return (
    <tr className="border-b hover:bg-gray-50">
      <td className="py-3 px-2 font-medium">#{id}</td>
      <td className="py-3 px-2 text-gray-600">{date}</td>
      <td className="py-3 px-2">{customer}</td>
      <td className="py-3 px-2">
        <span className={`px-2 py-1 rounded-full text-xs ${statusColors[status]}`}>
          {statusText[status]}
        </span>
      </td>
      <td className="py-3 px-2">{items}</td>
      <td className="py-3 px-2 text-right font-medium">R${amount.toFixed(2)}</td>
    </tr>
  );
}
