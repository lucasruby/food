import { useState } from 'react';
import { Pizza, MenuItem, Promotion } from '@shared/types';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Edit, Trash2 } from 'lucide-react';

type ItemType = Pizza | MenuItem | Promotion;

interface PizzaCardProps {
  item: ItemType;
  type: 'pizza' | 'menuItem' | 'promotion';
  onEdit: (item: ItemType) => void;
  onDelete: (id: string) => void;
}

export default function PizzaCard({ item, type, onEdit, onDelete }: PizzaCardProps) {
  const [isConfirmingDelete, setIsConfirmingDelete] = useState(false);

  const handleDelete = () => {
    if (isConfirmingDelete) {
      onDelete(item.id);
      setIsConfirmingDelete(false);
    } else {
      setIsConfirmingDelete(true);
    }
  };

  return (
    <Card className="overflow-hidden">
      <div className="h-40 bg-gray-100 relative">
        {type === 'pizza' && (
          <svg className="w-full h-full text-[#FF6B00] opacity-20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4M7,7.5A1.5,1.5 0 0,0 5.5,9A1.5,1.5 0 0,0 7,10.5A1.5,1.5 0 0,0 8.5,9A1.5,1.5 0 0,0 7,7.5M11,10A1,1 0 0,0 10,11A1,1 0 0,0 11,12A1,1 0 0,0 12,11A1,1 0 0,0 11,10M15,10.5A1.5,1.5 0 0,0 13.5,12A1.5,1.5 0 0,0 15,13.5A1.5,1.5 0 0,0 16.5,12A1.5,1.5 0 0,0 15,10.5"/>
          </svg>
        )}
        
        {type === 'promotion' && (
          <div className="absolute top-0 right-0 bg-[#FF3A3A] text-white px-2 py-1 text-xs font-bold">
            PROMO
          </div>
        )}
      </div>
      
      <CardContent className="p-4">
        <div className="flex justify-between mb-2">
          <h3 className="font-bold text-lg">{item.name}</h3>
          <span className="font-bold text-[#FF6B00]">
            R${(item as any).price?.toFixed(2) || '0.00'}
          </span>
        </div>
        
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">
          {(item as any).description}
        </p>
        
        {type === 'pizza' && (
          <div className="text-xs text-gray-500 mb-3">
            <span className="font-semibold">Ingredientes: </span>
            {(item as Pizza).ingredients?.join(', ')}
          </div>
        )}
        
        {type === 'promotion' && (
          <div className="text-xs bg-gray-100 p-2 rounded mb-3">
            <span className="font-semibold">Inclui: </span>
            {(item as Promotion).items?.map((i: any, idx: number) => (
              <span key={idx}>
                {i.quantity}x {i.name || `${i.type} ${i.size || ''}`}
                {idx < (item as Promotion).items.length - 1 ? ', ' : ''}
              </span>
            ))}
          </div>
        )}
        
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => onEdit(item)}
            className="flex items-center"
          >
            <Edit className="h-4 w-4 mr-1" />
            Editar
          </Button>
          
          <Button 
            variant={isConfirmingDelete ? "destructive" : "outline"} 
            size="sm" 
            onClick={handleDelete}
            className="flex items-center"
          >
            <Trash2 className="h-4 w-4 mr-1" />
            {isConfirmingDelete ? "Confirmar" : "Excluir"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
