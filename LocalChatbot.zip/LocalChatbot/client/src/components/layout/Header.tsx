import { useState } from 'react';
import { Settings, Menu as MenuIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { logoutWhatsApp, initWhatsApp } from '@/lib/api';

interface HeaderProps {
  toggleSidebar: () => void;
  businessName?: string;
  businessLogo?: string;
  whatsappStatus?: 'online' | 'offline' | 'connecting';
}

export default function Header({ 
  toggleSidebar, 
  businessName = 'Pizzaria Catalana',
  businessLogo,
  whatsappStatus = 'online'
}: HeaderProps) {
  const [isToggling, setIsToggling] = useState(false);
  const { toast } = useToast();

  const toggleWhatsappStatusMutation = useMutation({
    mutationFn: async () => {
      setIsToggling(true);
      if (whatsappStatus === 'online') {
        return await logoutWhatsApp();
      } else {
        return await initWhatsApp();
      }
    },
    onSuccess: () => {
      toast({
        title: whatsappStatus === 'online' ? 'WhatsApp desconectado' : 'WhatsApp conectado',
        description: whatsappStatus === 'online' 
          ? 'O serviço WhatsApp foi desconectado com sucesso.' 
          : 'O serviço WhatsApp foi iniciado. Verifique o QR code se necessário.',
      });
    },
    onError: () => {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao alterar o status do WhatsApp.',
        variant: 'destructive',
      });
    },
    onSettled: () => {
      setIsToggling(false);
    }
  });

  const handleToggleWhatsappStatus = () => {
    toggleWhatsappStatusMutation.mutate();
  };

  return (
    <header className="bg-[#FF6B00] px-4 py-3 flex items-center justify-between shadow-md">
      <div className="flex items-center">
        <button 
          className="md:hidden mr-4 text-white" 
          onClick={toggleSidebar}
          aria-label="Toggle sidebar"
        >
          <MenuIcon className="h-6 w-6" />
        </button>
        
        <div className="flex items-center">
          {businessLogo ? (
            <img 
              src={businessLogo} 
              alt={`${businessName} Logo`} 
              className="w-10 h-10 rounded-full mr-3 object-cover" 
            />
          ) : (
            <div className="w-10 h-10 rounded-full mr-3 bg-white flex items-center justify-center">
              <span className="text-[#FF6B00] font-bold text-lg">
                {businessName.charAt(0)}
              </span>
            </div>
          )}
          
          <div>
            <h1 className="text-white font-['Roboto_Condensed'] font-bold text-xl">
              {businessName}
            </h1>
            <p className="text-white opacity-80 text-sm">Bot de Atendimento</p>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <button className="text-white p-2 rounded-full hover:bg-[#D95800] transition-colors">
          <Settings className="h-6 w-6" />
        </button>
        
        <Button
          onClick={handleToggleWhatsappStatus}
          disabled={isToggling}
          className={`font-bold text-sm ${
            whatsappStatus === 'online' 
              ? 'bg-green-600 hover:bg-green-700' 
              : whatsappStatus === 'connecting'
                ? 'bg-yellow-500 hover:bg-yellow-600'
                : 'bg-red-500 hover:bg-red-600'
          }`}
        >
          Status: {isToggling ? 'Alterando...' : whatsappStatus === 'connecting' ? 'Conectando' : whatsappStatus}
        </Button>
      </div>
    </header>
  );
}
