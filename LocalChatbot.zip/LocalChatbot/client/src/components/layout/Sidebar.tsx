import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { 
  MessageSquare, 
  ClipboardList, 
  Clock, 
  BarChart2, 
  Users, 
  Settings as SettingsIcon
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface BusinessOption {
  id: string;
  name: string;
}

interface SidebarProps {
  isOpen?: boolean;
  businessOptions?: BusinessOption[];
  selectedBusiness?: string;
  onBusinessChange?: (id: string) => void;
}

export default function Sidebar({ 
  isOpen = true, 
  businessOptions = [
    { id: '1', name: 'Pizzaria Catalana' },
    { id: '2', name: 'Restaurante Italiano' },
    { id: '3', name: 'Hamburgueria' },
  ],
  selectedBusiness = '1',
  onBusinessChange 
}: SidebarProps) {
  const [location] = useLocation();
  
  const handleBusinessChange = (value: string) => {
    if (onBusinessChange) {
      onBusinessChange(value);
    }
  };

  if (!isOpen) return null;

  return (
    <aside className="w-64 border-r border-gray-200 h-full bg-white">
      <div className="p-4 border-b border-gray-200">
        <h2 className="font-['Roboto_Condensed'] font-bold text-lg">Configurações do Bot</h2>
      </div>
      
      <nav className="py-4">
        <ul>
          <NavItem 
            href="/chat" 
            icon={<MessageSquare className="h-5 w-5 mr-3" />}
            label="Conversa de Exemplo"
            isActive={location === '/chat'}
          />
          
          <NavItem 
            href="/menu" 
            icon={<ClipboardList className="h-5 w-5 mr-3" />}
            label="Cardápio"
            isActive={location === '/menu'}
          />
          
          <NavItem 
            href="/promotions" 
            icon={<Clock className="h-5 w-5 mr-3" />}
            label="Promoções"
            isActive={location === '/promotions'}
          />
          
          <NavItem 
            href="/reports" 
            icon={<BarChart2 className="h-5 w-5 mr-3" />}
            label="Relatórios"
            isActive={location === '/reports'}
          />
          
          <NavItem 
            href="/customers" 
            icon={<Users className="h-5 w-5 mr-3" />}
            label="Clientes"
            isActive={location === '/customers'}
          />
          
          <NavItem 
            href="/settings" 
            icon={<SettingsIcon className="h-5 w-5 mr-3" />}
            label="Configurações"
            isActive={location === '/settings'}
          />
        </ul>
      </nav>

      <div className="p-4 mt-4 bg-gray-100">
        <h3 className="font-['Roboto_Condensed'] font-bold text-sm uppercase text-gray-500 mb-2">
          Adaptações
        </h3>
        <Select 
          value={selectedBusiness} 
          onValueChange={handleBusinessChange}
        >
          <SelectTrigger className="w-full bg-white">
            <SelectValue placeholder="Selecione um negócio" />
          </SelectTrigger>
          <SelectContent>
            {businessOptions.map(option => (
              <SelectItem key={option.id} value={option.id}>
                {option.name}
              </SelectItem>
            ))}
            <SelectItem value="new">+ Adicionar novo...</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </aside>
  );
}

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

function NavItem({ href, icon, label, isActive }: NavItemProps) {
  return (
    <li>
      <Link href={href}>
        <a 
          className={`flex items-center px-4 py-3 ${
            isActive 
              ? 'text-[#FF6B00] font-semibold border-l-4 border-[#FF6B00]' 
              : 'text-gray-600 hover:bg-gray-100'
          }`}
        >
          {icon}
          {label}
        </a>
      </Link>
    </li>
  );
}
