import { useState, useEffect } from 'react';
import { X, Plus, Minus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Pizza, MenuItem } from '@shared/types';

interface MenuEditorProps {
  isOpen: boolean;
  onClose: () => void;
  item?: Pizza | MenuItem;
  type: 'pizza' | 'menuItem';
  businessId: number;
  onSave: (item: Partial<Pizza | MenuItem>) => void;
}

export default function MenuEditor({
  isOpen,
  onClose,
  item,
  type,
  businessId,
  onSave
}: MenuEditorProps) {
  const [name, setName] = useState(item?.name || '');
  const [description, setDescription] = useState(item?.description || '');
  const [price, setPrice] = useState(item?.price?.toString() || '');
  const [category, setCategory] = useState(item?.category || (type === 'pizza' ? 'Tradicional' : 'Bebidas'));
  const [active, setActive] = useState(item?.active ?? true);
  const [size, setSize] = useState((item as Pizza)?.size || 'Grande');
  const [ingredients, setIngredients] = useState<string[]>((item as Pizza)?.ingredients || []);
  const [newIngredient, setNewIngredient] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (item) {
      setName(item.name);
      setDescription(item.description || '');
      setPrice(item.price.toString());
      setCategory(item.category);
      setActive(item.active ?? true);
      
      if (type === 'pizza') {
        setSize((item as Pizza).size || 'Grande');
        setIngredients((item as Pizza).ingredients || []);
      }
    } else {
      // Reset form for new item
      setName('');
      setDescription('');
      setPrice('');
      setCategory(type === 'pizza' ? 'Tradicional' : 'Bebidas');
      setActive(true);
      setSize('Grande');
      setIngredients([]);
    }
  }, [item, type, isOpen]);

  const handleAddIngredient = () => {
    if (newIngredient && !ingredients.includes(newIngredient)) {
      setIngredients([...ingredients, newIngredient]);
      setNewIngredient('');
    }
  };

  const handleRemoveIngredient = (ingredientToRemove: string) => {
    setIngredients(ingredients.filter(i => i !== ingredientToRemove));
  };

  const handleSave = async () => {
    if (!name || !price) {
      toast({
        title: 'Campos obrigatórios',
        description: 'Por favor, preencha todos os campos obrigatórios.',
        variant: 'destructive'
      });
      return;
    }

    setIsLoading(true);
    try {
      const saveData: any = {
        businessId,
        name,
        description,
        price: parseFloat(price),
        category,
        active
      };
      
      if (type === 'pizza') {
        saveData.size = size;
        saveData.ingredients = ingredients;
      }
      
      await onSave(saveData);
      
      toast({
        title: 'Item salvo',
        description: `O item ${name} foi salvo com sucesso.`
      });
      
      onClose();
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao salvar o item.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-['Roboto_Condensed'] font-bold text-lg">
            {item ? 'Editar' : 'Adicionar'} {type === 'pizza' ? 'Pizza' : 'Item de Menu'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="p-4">
          <div className="grid gap-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome *</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nome do item"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="price">Preço (R$) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrição do item"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger id="category">
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {type === 'pizza' ? (
                      <>
                        <SelectItem value="Tradicional">Tradicional</SelectItem>
                        <SelectItem value="Especial">Especial</SelectItem>
                        <SelectItem value="Doce">Doce</SelectItem>
                      </>
                    ) : (
                      <>
                        <SelectItem value="Bebidas">Bebidas</SelectItem>
                        <SelectItem value="Sobremesas">Sobremesas</SelectItem>
                        <SelectItem value="Acompanhamentos">Acompanhamentos</SelectItem>
                      </>
                    )}
                  </SelectContent>
                </Select>
              </div>
              
              {type === 'pizza' && (
                <div>
                  <Label htmlFor="size">Tamanho</Label>
                  <Select value={size} onValueChange={setSize}>
                    <SelectTrigger id="size">
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Pequena">Pequena</SelectItem>
                      <SelectItem value="Média">Média</SelectItem>
                      <SelectItem value="Grande">Grande</SelectItem>
                      <SelectItem value="Gigante">Gigante</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            
            {type === 'pizza' && (
              <div>
                <Label>Ingredientes</Label>
                <div className="flex space-x-2 mb-2">
                  <Input
                    value={newIngredient}
                    onChange={(e) => setNewIngredient(e.target.value)}
                    placeholder="Adicionar ingrediente"
                    onKeyPress={(e) => e.key === 'Enter' && handleAddIngredient()}
                  />
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={handleAddIngredient}
                    disabled={!newIngredient}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                
                <div className="bg-gray-50 p-2 rounded min-h-[100px] max-h-[150px] overflow-y-auto">
                  {ingredients.length === 0 ? (
                    <p className="text-gray-400 text-sm text-center py-4">
                      Nenhum ingrediente adicionado
                    </p>
                  ) : (
                    <ul className="space-y-1">
                      {ingredients.map((ingredient, index) => (
                        <li key={index} className="flex justify-between items-center text-sm bg-white p-2 rounded">
                          {ingredient}
                          <Button 
                            type="button" 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleRemoveIngredient(ingredient)}
                          >
                            <Minus className="h-4 w-4 text-red-500" />
                          </Button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            )}
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="active" 
                checked={active} 
                onCheckedChange={setActive} 
              />
              <Label htmlFor="active">Ativo</Label>
            </div>
          </div>
        </div>
        
        <DialogFooter className="p-4 border-t border-gray-200">
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? 'Salvando...' : 'Salvar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
