import { useState, useEffect } from 'react';
import { X, Plus, Minus } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Promotion, PromotionItem } from '@shared/types';

interface PromotionEditorProps {
  isOpen: boolean;
  onClose: () => void;
  promotion?: Promotion;
  businessId: number;
  onSave: (promotion: Partial<Promotion>) => void;
  pizzaOptions: Array<{ id: string; name: string; size?: string }>;
  drinkOptions: Array<{ id: string; name: string }>;
}

export default function PromotionEditor({
  isOpen,
  onClose,
  promotion,
  businessId,
  onSave,
  pizzaOptions,
  drinkOptions
}: PromotionEditorProps) {
  const [name, setName] = useState(promotion?.name || '');
  const [description, setDescription] = useState(promotion?.description || '');
  const [price, setPrice] = useState(promotion?.price?.toString() || '');
  const [items, setItems] = useState<PromotionItem[]>(promotion?.items || []);
  const [active, setActive] = useState(promotion?.active ?? true);
  
  const [newItemType, setNewItemType] = useState<'pizza' | 'drink' | 'other'>('pizza');
  const [newItemName, setNewItemName] = useState('');
  const [newItemSize, setNewItemSize] = useState('Grande');
  const [newItemBorder, setNewItemBorder] = useState('');
  const [newItemQuantity, setNewItemQuantity] = useState('1');
  
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (promotion) {
      setName(promotion.name);
      setDescription(promotion.description);
      setPrice(promotion.price.toString());
      setItems(promotion.items || []);
      setActive(promotion.active ?? true);
    } else {
      // Reset form for new promotion
      setName('');
      setDescription('');
      setPrice('');
      setItems([]);
      setActive(true);
    }
  }, [promotion, isOpen]);

  const handleAddItem = () => {
    const newItem: PromotionItem = {
      type: newItemType,
      name: newItemName || (newItemType === 'pizza' ? 'Pizza' : newItemType === 'drink' ? 'Bebida' : 'Item'),
      quantity: parseInt(newItemQuantity) || 1
    };

    if (newItemType === 'pizza') {
      newItem.size = newItemSize;
      if (newItemBorder) {
        newItem.border = newItemBorder;
      }
    }

    setItems([...items, newItem]);
    
    // Reset new item form
    setNewItemName('');
    setNewItemSize('Grande');
    setNewItemBorder('');
    setNewItemQuantity('1');
  };

  const handleRemoveItem = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  };

  const handleSave = async () => {
    if (!name || !price || items.length === 0) {
      toast({
        title: 'Campos obrigatórios',
        description: 'Por favor, preencha todos os campos obrigatórios e adicione pelo menos um item.',
        variant: 'destructive'
      });
      return;
    }

    setIsLoading(true);
    try {
      const promotionData: Partial<Promotion> = {
        businessId,
        name,
        description,
        price: parseFloat(price),
        items,
        active
      };
      
      await onSave(promotionData);
      
      toast({
        title: 'Promoção salva',
        description: `A promoção ${name} foi salva com sucesso.`
      });
      
      onClose();
    } catch (error) {
      toast({
        title: 'Erro',
        description: 'Ocorreu um erro ao salvar a promoção.',
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-['Roboto_Condensed'] font-bold text-lg">
            {promotion ? 'Editar' : 'Adicionar'} Promoção
          </DialogTitle>
        </DialogHeader>
        
        <div className="p-4">
          <div className="grid gap-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Nome da Promoção *</Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Ex: COMBO PREMIUM"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="price">Preço (R$) *</Label>
                <Input
                  id="price"
                  type="number"
                  step="0.01"
                  min="0"
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descrição da promoção"
                rows={2}
              />
            </div>
            
            {/* Items in promotion */}
            <div>
              <Label className="mb-2 block">Itens na Promoção</Label>
              
              <div className="bg-gray-50 p-4 rounded mb-4">
                <div className="grid grid-cols-12 gap-2 mb-2">
                  <div className="col-span-3">
                    <Label htmlFor="itemType">Tipo</Label>
                    <Select value={newItemType} onValueChange={(value: any) => setNewItemType(value)}>
                      <SelectTrigger id="itemType">
                        <SelectValue placeholder="Tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pizza">Pizza</SelectItem>
                        <SelectItem value="drink">Bebida</SelectItem>
                        <SelectItem value="other">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="col-span-3">
                    <Label htmlFor="itemName">Nome</Label>
                    <Input
                      id="itemName"
                      value={newItemName}
                      onChange={(e) => setNewItemName(e.target.value)}
                      placeholder={newItemType === 'pizza' ? 'Pizza' : newItemType === 'drink' ? 'Bebida' : 'Item'}
                    />
                  </div>
                  
                  {newItemType === 'pizza' && (
                    <>
                      <div className="col-span-2">
                        <Label htmlFor="itemSize">Tamanho</Label>
                        <Select value={newItemSize} onValueChange={setNewItemSize}>
                          <SelectTrigger id="itemSize">
                            <SelectValue placeholder="Tamanho" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Pequena">Pequena</SelectItem>
                            <SelectItem value="Média">Média</SelectItem>
                            <SelectItem value="Grande">Grande</SelectItem>
                            <SelectItem value="Gigante">Gigante</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="col-span-2">
                        <Label htmlFor="itemBorder">Borda</Label>
                        <Select value={newItemBorder} onValueChange={setNewItemBorder}>
                          <SelectTrigger id="itemBorder">
                            <SelectValue placeholder="Sem borda" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="">Sem borda</SelectItem>
                            <SelectItem value="Catupiry">Catupiry</SelectItem>
                            <SelectItem value="Cheddar">Cheddar</SelectItem>
                            <SelectItem value="Chocolate">Chocolate</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </>
                  )}
                  
                  <div className={`${newItemType === 'pizza' ? 'col-span-1' : 'col-span-3'}`}>
                    <Label htmlFor="itemQuantity">Qtd.</Label>
                    <Input
                      id="itemQuantity"
                      type="number"
                      min="1"
                      value={newItemQuantity}
                      onChange={(e) => setNewItemQuantity(e.target.value)}
                    />
                  </div>
                  
                  <div className={`${newItemType === 'pizza' ? 'col-span-1' : 'col-span-3'} flex items-end`}>
                    <Button 
                      onClick={handleAddItem} 
                      variant="outline" 
                      className="w-full"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* List of added items */}
              <div className="bg-gray-50 p-2 rounded min-h-[100px] max-h-[200px] overflow-y-auto">
                {items.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-4">
                    Nenhum item adicionado
                  </p>
                ) : (
                  <ul className="space-y-1">
                    {items.map((item, index) => (
                      <li key={index} className="flex justify-between items-center text-sm bg-white p-2 rounded">
                        <div>
                          <span className="font-medium">{item.quantity}x </span>
                          {item.type === 'pizza' ? (
                            <>
                              Pizza {item.size} 
                              {item.border ? ` com borda de ${item.border}` : ''}
                              {item.name !== 'Pizza' ? ` (${item.name})` : ''}
                            </>
                          ) : (
                            item.name
                          )}
                        </div>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleRemoveItem(index)}
                        >
                          <Minus className="h-4 w-4 text-red-500" />
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch 
                id="active" 
                checked={active} 
                onCheckedChange={setActive} 
              />
              <Label htmlFor="active">Ativo</Label>
            </div>
          </div>
        </div>
        
        <DialogFooter className="p-4 border-t border-gray-200">
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? 'Salvando...' : 'Salvar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
