import { useRef, useEffect } from 'react';
import Message from './Message';
import { Message as MessageType } from '@shared/types';

interface ChatContainerProps {
  messages: MessageType[];
}

export default function ChatContainer({ messages }: ChatContainerProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <div 
      ref={containerRef}
      className="flex-grow overflow-y-auto p-4 bg-[#e5ddd5] bg-opacity-80"
    >
      {messages.length === 0 ? (
        <div className="flex items-center justify-center h-full">
          <p className="text-gray-500 text-center">
            Nenhuma mensagem ainda. Comece a conversa digitando abaixo.
          </p>
        </div>
      ) : (
        messages.map((message, index) => (
          <Message 
            key={index} 
            message={message} 
            isUser={message.role === 'user'}
          />
        ))
      )}
    </div>
  );
}
