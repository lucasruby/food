import { format } from 'date-fns';
import { Message as MessageType } from '@shared/types';

interface MessageProps {
  message: MessageType;
  isUser?: boolean;
}

export default function Message({ message, isUser = false }: MessageProps) {
  const timestamp = message.timestamp || new Date();
  const formattedTime = format(
    typeof timestamp === 'string' ? new Date(timestamp) : timestamp,
    'HH:mm'
  );

  return (
    <div className={`flex mb-4 ${isUser ? 'justify-end' : ''}`}>
      <div 
        className={`max-w-[80%] ${
          isUser 
            ? 'bg-green-100' 
            : 'bg-white'
        } rounded-lg p-3 shadow`}
      >
        {message.content.split('\n').map((line, index) => {
          // Check if line is a section title (with emoji)
          if (/^(🍕|🥤|🔥)\s+.*:$/i.test(line)) {
            return (
              <p key={index} className="text-sm font-bold mt-2 mb-1">
                {line}
              </p>
            );
          }
          
          // Check if line is a subsection title
          else if (/^[A-Za-z\s]+(disponíveis|Tradicionais):$/i.test(line)) {
            return (
              <p key={index} className="text-sm font-semibold">{line}</p>
            );
          }
          
          // Check if line is a promotion
          else if (/^(COMBO\s+.*)\s+-\s+R\$\d+/i.test(line)) {
            return (
              <div key={index} className="bg-[#FF3A3A] bg-opacity-10 p-2 rounded-md border border-[#FF3A3A] border-opacity-30 mt-2">
                <p className="text-sm font-bold text-[#FF3A3A]">{line}</p>
              </div>
            );
          }
          
          // Regular text line
          else {
            return (
              <p key={index} className={`text-sm ${index > 0 ? 'mt-1' : 'mb-1'}`}>
                {line}
              </p>
            );
          }
        })}
        
        <span className="text-xs text-gray-500">{formattedTime}</span>
      </div>
    </div>
  );
}
