import { useState, KeyboardEvent } from 'react';
import { Send, Smile } from 'lucide-react';

interface InputAreaProps {
  onSendMessage: (message: string) => void;
  placeholder?: string;
  disabled?: boolean;
}

export default function InputArea({ 
  onSendMessage, 
  placeholder = "Digite uma mensagem para testar o bot...",
  disabled = false
}: InputAreaProps) {
  const [message, setMessage] = useState('');

  const handleSendMessage = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message);
      setMessage('');
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="border-t border-gray-200 p-4 bg-gray-50">
      <div className="flex items-center">
        <div className="flex-grow relative">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder={placeholder}
            disabled={disabled}
            className="w-full p-3 pr-12 border border-gray-300 rounded-full focus:outline-none focus:border-[#FF6B00]"
          />
          <button 
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-[#FF6B00]"
            aria-label="Emojis"
          >
            <Smile className="h-6 w-6" />
          </button>
        </div>
        <button
          onClick={handleSendMessage}
          disabled={!message.trim() || disabled}
          className={`ml-2 bg-[#FF6B00] text-white p-3 rounded-full flex items-center justify-center ${
            !message.trim() || disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#D95800]'
          }`}
          aria-label="Enviar mensagem"
        >
          <Send className="h-6 w-6" />
        </button>
      </div>
    </div>
  );
}
