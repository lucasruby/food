import { Message } from "@shared/types";

// Note: This is just for the client-side API interface
// The actual OpenAI API calls will be handled by the server

export interface GenerateResponseParams {
  messages: Message[];
  temperature?: number;
}

export interface ProcessOrderParams {
  messages: Message[];
  orderContext: Record<string, any>;
}

export interface ProcessOrderResult {
  updatedOrderContext: Record<string, any>;
  response: string;
}

export interface AnalyzeIntentResult {
  intent: string;
  confidence: number;
}

// These methods will call the server API which will then call OpenAI
export async function generateResponse(params: GenerateResponseParams): Promise<string> {
  try {
    const response = await fetch('/api/openai/generate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    return data.response || data; // Return response or raw data if response.response is undefined
  } catch (error) {
    console.error('Error in generateResponse:', error);
    throw new Error('Falha ao gerar resposta');
  }
}

export async function processOrder(params: ProcessOrderParams): Promise<ProcessOrderResult> {
  try {
    const response = await fetch('/api/openai/process-order', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error processing order:', error);
    return {
      updatedOrderContext: params.orderContext,
      response: 'Error processing order'
    };
  }
}

export async function analyzeIntent(message: string): Promise<AnalyzeIntentResult> {
  try {
    const response = await fetch('/api/openai/analyze-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ message }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error analyzing intent:', error);
    return {
      intent: 'unknown',
      confidence: 0,
    };
  }
}