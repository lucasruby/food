import { apiRequest } from "./queryClient";
import { Business, Pizza, MenuItem, Promotion, Prompt, Customer, Order } from "@shared/schema";

// Business API
export async function getBusiness(id: number): Promise<Business> {
  const res = await apiRequest("GET", `/api/businesses/${id}`);
  return res.json();
}

export async function getBusinesses(): Promise<Business[]> {
  const res = await apiRequest("GET", "/api/businesses");
  return res.json();
}

export async function createBusiness(business: Omit<Business, "id">): Promise<Business> {
  const res = await apiRequest("POST", "/api/businesses", business);
  return res.json();
}

export async function updateBusiness(id: number, business: Partial<Business>): Promise<Business> {
  const res = await apiRequest("PUT", `/api/businesses/${id}`, business);
  return res.json();
}

export async function deleteBusiness(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/businesses/${id}`);
}

// Pizza API
export async function getPizzasByBusiness(businessId: number): Promise<Pizza[]> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/pizzas`);
  return res.json();
}

export async function createPizza(pizza: Omit<Pizza, "id">): Promise<Pizza> {
  const res = await apiRequest("POST", "/api/pizzas", pizza);
  return res.json();
}

export async function updatePizza(id: number, pizza: Partial<Pizza>): Promise<Pizza> {
  const res = await apiRequest("PUT", `/api/pizzas/${id}`, pizza);
  return res.json();
}

export async function deletePizza(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/pizzas/${id}`);
}

// Menu Item API
export async function getMenuItemsByBusiness(businessId: number): Promise<MenuItem[]> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/menuitems`);
  return res.json();
}

export async function createMenuItem(menuItem: Omit<MenuItem, "id">): Promise<MenuItem> {
  const res = await apiRequest("POST", "/api/menuitems", menuItem);
  return res.json();
}

export async function updateMenuItem(id: number, menuItem: Partial<MenuItem>): Promise<MenuItem> {
  const res = await apiRequest("PUT", `/api/menuitems/${id}`, menuItem);
  return res.json();
}

export async function deleteMenuItem(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/menuitems/${id}`);
}

// Promotion API
export async function getPromotionsByBusiness(businessId: number): Promise<Promotion[]> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/promotions`);
  return res.json();
}

export async function createPromotion(promotion: Omit<Promotion, "id">): Promise<Promotion> {
  const res = await apiRequest("POST", "/api/promotions", promotion);
  return res.json();
}

export async function updatePromotion(id: number, promotion: Partial<Promotion>): Promise<Promotion> {
  const res = await apiRequest("PUT", `/api/promotions/${id}`, promotion);
  return res.json();
}

export async function deletePromotion(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/promotions/${id}`);
}

// Prompt API
export async function getPromptsByBusiness(businessId: number): Promise<Prompt[]> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/prompts`);
  return res.json();
}

export async function getActivePrompt(businessId: number): Promise<Prompt> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/prompts/active`);
  return res.json();
}

export async function createPrompt(prompt: Omit<Prompt, "id">): Promise<Prompt> {
  const res = await apiRequest("POST", "/api/prompts", prompt);
  return res.json();
}

export async function updatePrompt(id: number, prompt: Partial<Prompt>): Promise<Prompt> {
  const res = await apiRequest("PUT", `/api/prompts/${id}`, prompt);
  return res.json();
}

export async function deletePrompt(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/prompts/${id}`);
}

// WhatsApp API
export async function getWhatsAppStatus() {
  const res = await apiRequest("GET", "/api/whatsapp/status");
  return res.json();
}

export async function initWhatsApp() {
  const res = await apiRequest("POST", "/api/whatsapp/init");
  return res.json();
}

export async function logoutWhatsApp() {
  const res = await apiRequest("POST", "/api/whatsapp/logout");
  return res.json();
}

export async function restartWhatsApp() {
  const res = await apiRequest("POST", "/api/whatsapp/restart");
  return res.json();
}

// Customer API
export async function getCustomersByBusiness(businessId: number): Promise<Customer[]> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/customers`);
  return res.json();
}

export async function getCustomer(id: number): Promise<Customer> {
  const res = await apiRequest("GET", `/api/customers/${id}`);
  return res.json();
}

export async function getCustomerByPhone(phone: string): Promise<Customer> {
  const res = await apiRequest("GET", `/api/customers/phone/${phone}`);
  return res.json();
}

export async function createCustomer(customer: Omit<Customer, "id">): Promise<Customer> {
  const res = await apiRequest("POST", "/api/customers", customer);
  return res.json();
}

export async function updateCustomer(id: number, customer: Partial<Customer>): Promise<Customer> {
  const res = await apiRequest("PUT", `/api/customers/${id}`, customer);
  return res.json();
}

export async function deleteCustomer(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/customers/${id}`);
}

// Order API
export async function getOrdersByBusiness(businessId: number): Promise<Order[]> {
  const res = await apiRequest("GET", `/api/businesses/${businessId}/orders`);
  return res.json();
}

export async function getOrdersByCustomer(phone: string): Promise<Order[]> {
  const res = await apiRequest("GET", `/api/customers/${phone}/orders`);
  return res.json();
}

export async function getOrder(id: number): Promise<Order> {
  const res = await apiRequest("GET", `/api/orders/${id}`);
  return res.json();
}

export async function createOrder(order: Omit<Order, "id">): Promise<Order> {
  const res = await apiRequest("POST", "/api/orders", order);
  return res.json();
}

export async function updateOrder(id: number, order: Partial<Order>): Promise<Order> {
  const res = await apiRequest("PUT", `/api/orders/${id}`, order);
  return res.json();
}

export async function deleteOrder(id: number): Promise<void> {
  await apiRequest("DELETE", `/api/orders/${id}`);
}
